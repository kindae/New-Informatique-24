<?php
require_once "php/config.php";

if (isset($_GET['infos']) AND !empty($_GET['infos'])){

    $id_mot = $_GET['infos'];

    $selmot = $bdd->prepare("SELECT * FROM dico WHERE id_mot = ? AND actif_mot = ?");
    $selmot->execute(array($id_mot, "0"));
    $selmot_row = $selmot->rowCount();

    if ($selmot_row == 1){

        $mot_view = $selmot->fetch();
        
        $mot = $mot_view['mot'];
        $desc_mot = $mot_view['desc_mot'];
        $image_mot = $mot_view['image_mot'];
        $date_mot = $mot_view['date_mot'];
        

        $id_nom_mot = $mot_view['ut_mot'];
        $sel_nom_mot = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
        $sel_nom_mot->execute(array($id_nom_mot));
    
        $nom_mot_row = $sel_nom_mot->rowCount();
    
        if ($nom_mot_row == 1) {
            
            $nom_mot_ft = $sel_nom_mot->fetch();
            $nom_mot = $nom_mot_ft['nom'];

        } else {

            $nom_mot = "inconnu";
        } 

    } else {

        header("Location: dico.php");

    }

} else {

    header("Location: dico.php");

}


$og_titre = "(New Informatique 24) " . $mot;
$og_desc = substr(htmlspecialchars($desc_mot), 0, 150) . "...";
$og_image = "https://newinformatique24.com/images/dico/" . $image_mot;


?>

<!DOCTYPE html>
<html>
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti, cours, tutoriel">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png">

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/apercu.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/tuto.css">

    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body>
     
    <?php include "inc/header.php" ?>
     
    <div id="c">

        <?php include "inc/menu.php" ?>

        <div id="pr">
            <div class="apercu_tuto"> 
                <p class="date">
                    <span>Posté Par: <?= $nom_mot ?></span>
                    <span>Creer: <?= date("d F Y, H:i",strtotime($date_mot))?></span>
                </p>
                <p>Pour en savoir plus lire :</p>

                <img class="youtube" src="images/dico/<?= $image_mot ?>"></img>
                
                <br><br>
                <h2><?= $mot ?></h2>

                <style>
                    p.contenu{
                        padding: 25px 10px;
                    }
                    p.contenu img{
                        display: block;
                        width: 300px;
                        padding: 20px;
                    }
                    @media (max-width: 920px){
                        p.contenu{
                            padding: 25px 10px;
                        }
                        p.contenu img{
                            display: block;
                            width: 100%;
                            padding: 20px 0;
                            margin: 0 auto;
                        }
                    }
                </style>
                <p class="contenu"><?= nl2br($desc_mot) ?></p>

                
            </div>
        </div>
    </div>

    <?php include "inc/secondaire.php" ?>

    <?php include "inc/footer.php" ?>

</body>
</html>