<?php
require_once "php/config.php";

if (isset($_GET['infos']) AND !empty($_GET['infos'])){

    $id_annonce = $_GET['infos'];

    $selannonce = $bdd->prepare("SELECT * FROM annonces WHERE id = ?");
    $selannonce->execute(array($id_annonce));
    $selannonce_row = $selannonce->rowCount();

    if ($selannonce_row == 1){

        $view_annonce = $selannonce->fetch();
        
        $annonce = $view_annonce['titre'];
        $texte = $view_annonce['texte'];
        $image = $view_annonce['image'];
        $date = $view_annonce['date'];
        

        $id_nom_annonce = $view_annonce['utilisateur'];
        $sel_nom_annonce = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
        $sel_nom_annonce->execute(array($id_nom_annonce));
    
        $nom_annonce_row = $sel_nom_annonce->rowCount();
    
        if ($nom_annonce_row == 1) {
            
            $nom_annonce_ft = $sel_nom_annonce->fetch();
            $nom_annonce = $nom_annonce_ft['nom'];

        } else {

            $nom_annonce = "inconnu";
        } 

    } else {

        header("Location: annonces.php");

    }

} else {

    header("Location: dico.php");

}


$og_titre = "(New Informatique 24) " . $annonce;
$og_desc = substr(htmlspecialchars($texte), 0, 150) . "...";
$og_image = "https://newinformatique24.com/images/annonces/" . $image;


?>

<!DOCTYPE html>
<html>
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti, cours, tutoriel">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png">

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/apercu.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/tuto.css">

    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body>
     
    <?php include "inc/header.php" ?>
     
    <div id="c">

        <?php include "inc/menu.php" ?>

        <div id="pr">
            <div class="apercu_tuto"> 
                <p class="date">
                    <span>Posté Par: <?= $nom_annonce ?></span>
                    <span>Creer: <?= date("d F Y, H:i",strtotime($date))?></span>
                </p>
                <p>Pour en savoir plus lire :</p>

                <img class="youtube" src="images/annonces/<?= $image ?>"></img>
                
                <br><br>
                <h2><?= $annonce ?></h2>

                <style>
                    p.contenu{
                        padding: 25px 10px;
                    }
                    p.contenu img{
                        display: block;
                        width: 300px;
                        padding: 20px;
                    }
                    @media (max-width: 920px){
                        p.contenu{
                            padding: 25px 10px;
                        }
                        p.contenu img{
                            display: block;
                            width: 100%;
                            padding: 20px 0;
                            margin: 0 auto;
                        }
                    }
                </style>
                <p class="contenu"><?= nl2br($texte) ?></p>
                
            </div>
        </div>
    </div>

    <?php include "inc/secondaire.php" ?>

    <?php include "inc/footer.php" ?>

</body>
</html>