<?php
require_once "php/config.php";

$citation_selection = $bdd->query("SELECT * FROM citations");
$citation_nombre = $citation_selection->rowCount();

$citation_id = rand(1, $citation_nombre);
$citations = $bdd->prepare("SELECT * FROM citations WHERE id = ?");
$citations->execute(array($citation_id));

$citation_id_2 = rand(1, $citation_nombre);
$citations_2 = $bdd->prepare("SELECT * FROM citations WHERE id = ?");
$citations_2->execute(array($citation_id_2));

$citation_id_3 = rand(1, $citation_nombre);
$citations_3 = $bdd->prepare("SELECT * FROM citations WHERE id = ?");
$citations_3->execute(array($citation_id_3));


$last_tutoriels = $bdd->prepare("SELECT * FROM tutoriels WHERE actif_tuto = ? ORDER BY date_ed_tuto DESC LIMIT 0,2");
$last_tutoriels->execute(array(0));

$tutoriel_selection = $bdd->query("SELECT * FROM tutoriels");
$tutoriel_nombre = $tutoriel_selection->rowCount();

$tutoriel_id = rand(1, $tutoriel_nombre);
$tutoriel_id2 = rand(2, $tutoriel_nombre);
$tutoriels = $bdd->prepare("SELECT * FROM tutoriels WHERE id_tuto = ? AND actif_tuto = ? OR id_tuto = ? AND actif_tuto = ?");
$tutoriels->execute(array($tutoriel_id,0, $tutoriel_id2,0));

$annonces = $bdd->query("SELECT * FROM annonces ORDER BY date DESC LIMIT 0,4");

//$cours = $bdd->prepare("SELECT * FROM cours WHERE actif_cours = ? ORDER BY date_cours DESC LIMIT 0,2");
//$cours->execute(array(0));



$og_titre = "New Informatique 24";
$og_desc = "Vous trouverez des ressources sur : \n\r \n\r - Des cours sur le domaine informatique \n\r - Des tutoriels présentant une tâche précise et initiant sur la façon de l'accomplir \n\r - Des explications sur differents mots du jargon informatique \n\r - et tant d'autres annonces interssantes sur le monde info...";
$og_image = "https://newinformatique24.com/logo.jpg";

?>

<!DOCTYPE html>
<html>
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti, cours, tutoriel">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png">  

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    
    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body>
     
    <?php include "inc/header.php" ?>
     
    <div id="c">

        <?php include "inc/menu.php" ?>

        <div id="pr">

            <div class="ac">
                <h1>Qu'apprendrez-vous sur New Informatique ?</h1>
                <img src="images/items/nit24.jpg" alt="cours">
                <p>
                    Vous trouverez des ressources sur :
                    <br><br>

                    - Des cours sur le domaine informatique <br>
                    - Des tutoriels présentant une tâche précise et initiant sur la façon de l'accomplir <br>
                    - Des explications sur differents mots du jargon informatique <br>
                    - et tant d'autres annonces interssantes sur le monde informatique !       
                </p>
            </div>
            <br>
            
            <?php while($citation = $citations->fetch()){ ?>
            <div class="ac">
                <h1>- Motivateur -</h1>
                <img src="images/citations/<?= $citation['image'] ?>" alt="<?= $citation['texte'] ?>">
                <p>
                    <?= $citation['texte'] ?>
                </p>
            </div>
            <?php } ?>

            <br>

            <?php while($tutoriel = $tutoriels->fetch()){ ?>
            <div class="ac">
                <h1><?= $tutoriel['titre_tuto'] ?></h1>
                <img src="images/tuto/<?= $tutoriel['image_tuto'] ?>" alt="<?= $tutoriel['titre_tuto'] ?>">
                <p>
                    <?= substr(htmlspecialchars($tutoriel['contenu_tuto']), 0, 500) ?> ...
                </p>
                <a href="tutoriel.php?tuto=<?= $tutoriel['id_tuto'] ?>">Lire la suite</a>
            </div>
            <?php } ?>

            <br>

            <?php while($citation_2 = $citations_2->fetch()){ ?>
            <div class="ac">
                <h1>- Motivateur -</h1>
                <img src="images/citations/<?= $citation_2['image'] ?>" alt="<?= $citation_2['texte'] ?>">
                <p>
                    <?= $citation_2['texte'] ?>
                </p>
            </div>
            <?php } ?>

            <br>

            <?php while($last_tutoriel = $last_tutoriels->fetch()){ ?>
            <div class="ac">
                <h1><?= $last_tutoriel['titre_tuto'] ?></h1>
                <img src="images/tuto/<?= $last_tutoriel['image_tuto'] ?>" alt="<?= $last_tutoriel['titre_tuto'] ?>">
                <p>
                    <?= substr(htmlspecialchars($last_tutoriel['contenu_tuto']), 0, 500) ?> ...
                </p>
                <a href="tutoriel.php?tuto=<?= $last_tutoriel['id_tuto'] ?>">Lire la suite</a>
            </div>
            <?php } ?>

            <br>
    
            <?php while($citation_3 = $citations_3->fetch()){ ?>
            <div class="ac">
                <h1>- Motivateur -</h1>
                <img src="images/citations/<?= $citation_3['image'] ?>" alt="<?= $citation_3['texte'] ?>">
                <p>
                    <?= $citation_3['texte'] ?>
                </p>
            </div>
            <?php } ?>

            <br>

            <?php while($annonce = $annonces->fetch()){ ?>
            <div class="ac">
                <h1><?= $annonce['titre'] ?></h1>
                <img src="images/annonces/<?= $annonce['image'] ?>" alt="<?= $annonce['titre'] ?>">
                <p>
                    <?= substr(htmlspecialchars($annonce['texte']), 0, 500) ?> ...
                </p>
                <a href="annonce.php?infos=<?= $annonce['id'] ?>">Lire la suite</a>
            </div>
            <?php } ?>

            <br>

            <!-- // while($c = $cours->fetch()){
            <div class="ac">
                <h1> // $c['nom_cours'] </h1>
                <img src="images/cours/ // $c['image_cours'] " alt=" // $c['nom_cours'] ">
                <p>
                     // substr(htmlspecialchars($c['desc_cours']), 0, 500)  ...
                </p>
                <a href="cours.php?infos= // $c['id_cours'] ">Lire la suite</a>
            </div>
            // }  -->

            <br>           
        </div>
    </div>

    <?php include "inc/secondaire.php" ?>

    <?php include "inc/footer.php" ?>

</body>
</html>