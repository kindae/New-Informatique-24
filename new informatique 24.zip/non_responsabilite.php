<?php

$og_titre = "Clause de non-resposabilité";
$og_desc = "Vous pouvez visiter ce site sans nous dire qui vous êtes ou sans nous donner des informations sur vous. Cependant, il existe des situations où nous aurons besoin d’informations, par exemple pour entretenir une correspondance avec vous, pour une réservation ou une inscription. Nous tenterons toujours de vous informer avant de rassembler des informations personnelles sur internet. Ce site web compte le nombre de visiteurs à l’aide d’un co...";
$og_image = "https://newinformatique24.com/logo.jpg";


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Clause de non-responsabilté, Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png">

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/styles_sc.css">

    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body>
<header>
        <a href="accueil" class="title">
            <img src="logo.png" alt="logo new informatique 24">
            <span>New Informatique 24</span>
        </a>

        <a href="accueil" class="btn">Retour</a>
    </header>

    <div class="aff_text">
        <div class="titre">
            <h1>Clause de non-responsabilité</h1>
            <p>
                Ce qui suit s’applique à l'utilisation du site web. En utilisant cette site web, vous acceptez cette clause de non-responsabilité.
            </p>
        </div>
        <div class="list">
            <h2>Vie privée</h2>
            <p>
                Vous pouvez visiter ce site sans nous dire qui vous êtes ou sans nous donner des informations sur vous. Cependant, il existe des situations où nous aurons besoin d’informations, par exemple pour entretenir une correspondance avec vous, pour une réservation ou une inscription. Nous tenterons toujours de vous informer avant de rassembler des informations personnelles sur internet. Ce site web compte le nombre de visiteurs à l’aide d’un compteur, les sites par quelles ils arrivent sur notre site et quel est leur fournisseur de connexion. Les résultats sont utilisés uniquement sous forme agrégée et non individuellement identifiables.
                <br><br>

                Les données (personnelles) collectées ne seront pas vendues ou mises à la disposition d’un tiers, sauf conditions particulières, par exemple si légalement requis. En outre, vous pouvez demander à tout moment la suppression de vos données de nos dossiers.
            </p>
        </div>
        <div class="list">
            <h2>Exclusion de responsabilité</h2>
            <p>
                Toutes les informations sur ce site web sont données pour une utilisation personnelle. Les informations sont non contractuelles. Sous réserve de modifications et erreurs de frappe. Nous nous efforçons de vous fournir des informations les plus complètes et exactes possibles. New Informatique 24 n’accepte aucune responsabilité pour des dommages, quels qu’ils soient, causés par l’utilisation, le caractère incomplet ou l’inexactitude des informations fournies sur ce site web.
            </p>
        </div>
        <div class="list">
            <h2>Disponibilité</h2>
            <p>
                Les informations et recommandations sur ce site sont susceptibles d’être modifiées sans avertissement ou information préalables. Nous nous efforçons de rendre disponible ce site web sans interruption, mais n’acceptons aucune responsabilité pour une indisponibilité (temporaire) du site.
            </p>
        </div>
        <div class="list">
            <h2>Droits d’auteur et droits de propriété intellectuelle</h2>
            <p>
                De droit d’auteur de ce site web appartient à New Informatique 24 ou aux tiers qui ont mis à disposition des images ou matériels et ont autorisé New Informatique 24 à les utiliser. La reproduction sous quelque forme que ce soit est uniquement autorisée après accord préalable de New Informatique 24.
            </p>
        </div>
    </div>

    <footer>
        <p>Copyright &copy; - New Informatique 24</p>
    </footer>
</body>
</html>