<?php
require_once "php/config.php";

$vrtutos = $bdd->prepare("SELECT * FROM tutoriels WHERE actif_tuto = ?");
$vrtutos->execute(array("0"));
$vrtutos_row = $vrtutos->rowCount();

if (isset($_GET['page']) AND !empty($_GET['page'])){

    $pageseld = ($_GET['page'] - 1)*10;
    $parpages = 10;
    $psel = $pageseld . "," . $parpages;

    $seltutos = $bdd->prepare("SELECT * FROM tutoriels WHERE actif_tuto = ? ORDER BY date_ed_tuto DESC LIMIT " . $psel);
    $seltutos->execute(array("0"));
    $seltutos_row = $seltutos->rowCount();

} elseif(isset($_GET['rc']) AND !empty($_GET['rc'])) {

    $rc_infos = $_GET['rc'];
    $seltutos = $bdd->prepare("SELECT * FROM tutoriels WHERE actif_tuto = ? AND titre_tuto LIKE ? ORDER BY date_ed_tuto DESC LIMIT 0,20");
    $seltutos->execute(array("0", "%$rc_infos%"));
    $seltutos_row = $seltutos->rowCount();

} else {

    $seltutos = $bdd->prepare("SELECT * FROM tutoriels WHERE actif_tuto = ? ORDER BY date_ed_tuto DESC LIMIT 0,10");
    $seltutos->execute(array("0"));
    $seltutos_row = $seltutos->rowCount();

}
    

$og_titre = "Tutoriels";
$og_desc = "Tutoriel vise a vous aider a faire des choses comme il faut en informatique, cette action est appellé entraide dans un site com...";
$og_image = "https://newinformatique24.com/logo.jpg";


?>

<!DOCTYPE html>
<html>
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti, cours, tutoriel">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png">

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/tuto.css">

    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body>
     
    <?php include "inc/header.php" ?>
     
    <div id="c">

        <?php include "inc/menu.php" ?>

        <div id="pr" class="tuto">

        <?php if (isset($_SESSION['id_ut'])) { 
            
            $vrnivtuto = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
            $vrnivtuto->execute(array($_SESSION['id_ut']));
            $nivuttuto = $vrnivtuto->fetch()['niveau'];

            if ($nivuttuto > 0 ) { ?>

                <div class="editeur">
                <a href="admin/editeur_tuto.php">
                    <img src="images/items/add.jpg" alt="image d'ajoute tutoriel">
                    <span>Ajouter un Tutoriel</span>
                </a>
                </div>

        <?php }} ?>
        
            <a class="tuto_aff">    
                <div>
                    <h3>Tutoriels</h3>
                    <p>Nos tutoriels visent a vous aider a faire des choses comme il faut en informatique, sorte d'une astuce ou d'un guide informatique !</p>
                    <p class="mob">Nos tutoriels visent a vous aider a faire des choses comme il faut en informatique, sorte d'une astuce ou d'un guide informatique !</p>
                    <p class="date">Annonce</p>
                </div>
            </a>
            <br><br>

        <?php while($tutos = $seltutos->fetch()) {
        
        ?>

            <a href="tutoriel=<?= $tutos['id_tuto'] ?>" class="tuto_aff">
                <img src="images/tuto/<?= $tutos['image_tuto']; ?>" alt="<?= $tutos['titre_tuto']; ?>">
                <div>
                    <h3><?= $tutos['titre_tuto']; ?></h3>
                    <p><?= substr( htmlspecialchars($tutos['contenu_tuto']), 0, 300) ?> ...</p>
                    <p class="mob"><?= substr( htmlspecialchars($tutos['contenu_tuto']), 0, 50) ?> ...</p>
                    <p class="date"><?= date("d F Y, H:i",strtotime($tutos['date_cr_tuto'])) ?></p>
                </div>
            </a>

        <?php } 
          
        if($seltutos_row == 0) { ?>

            <h1 style="color:white;">Pas de tutoriel trouver !</h1>
        
        <?php } ?>
        
        <?php if(!isset($rc_infos)){ ?>

            <div class="pagination">

            <?php $pagestutos = $vrtutos_row / 10;
            
            if(isset($_GET['page']) AND !empty($_GET['page'])){

                if ($pagestutos > $_GET['page']) { $pap = $_GET['page'] - 1; $pas = $_GET['page'] + 1;?>

                    <a href="tutoriels.php?page=<?= $pap ?>">Precedente</a>
                    <a href="tutoriels.php?page=<?= $pas ?>">Suivante</a>

                <?php } else { $pap = $_GET['page'] - 1; ?>

                    <a href="tutoriels.php?page=<?= $pap ?>">Precedente</a>
                    <a class="inactive">Suivante</a>

                <?php }

            } else {

                if ($vrtutos_row > 10) { ?>

                    <a class="inactive">Precedente</a>
                    <a href="tutoriels.php?page=2">Suivante</a>

            <?php } } ?>

            </div>

        <?php } ?>

        </div>
    </div>

    <?php include "inc/secondaire.php" ?>

    <?php include "inc/footer.php" ?>

</body>
</html>