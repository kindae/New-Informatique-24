<?php
header('Content-Type: application/rss+xml');
require "php/config.php";

$articles = $bdd->prepare('SELECT * FROM tutoriels WHERE actif_tuto = ? ORDER BY date_ed_tuto DESC LIMIT 0,25');
$articles->execute(array("0"));

$lastBuilDate = $bdd->prepare('SELECT * FROM tutoriels WHERE actif_tuto = ? ORDER BY date_ed_tuto DESC LIMIT 0,1');
$lastBuilDate->execute(array("0"));
$lastBuilDate = $lastBuilDate->fetch()['date_ed_tuto'];

?>
<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
	<channel>
		<title>New Informatique 24</title>
		<description>Apprendre l'informatique en quelque jours avec <b>New Informatique</b>. Nous avons des tutoriels et des cours, les cours sont donnés en ligne et sureveiller à 100%.</description>
		<lastBuilDate><?= date(DATE_RSS, strtotime($lastBuilDate)) ?></lastBuilDate>
		<link>https://newinformatique24.com</link>

		<?php while($a = $articles->fetch()) { ?>
		<item>
			<title><?= $a['titre_tuto'] ?></title>
			<description><?= substr($a['contenu_tuto'], 0, 300).'...' ?></description>
			<pubDate><?= date(DATE_RSS, strtotime($a['date_cr_tuto'])) ?></pubDate>
			<link>https://newinformatique24.com/tutoriel.php?tuto=<?= $a['id_tuto'] ?></link>
			<image>
				<url>https://newinformatique24.com/images/tuto/<?= $a['image_tuto']; ?></url>
				<link>https://newinformatique24.com/tutoriel.php?tuto=<?= $a['id_tuto'] ?></link>
			</image>
		</item>
		<?php }?>

	</channel>
</rss>