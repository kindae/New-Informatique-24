<?php
require_once "php/config.php";

if(isset($_GET['rc']) AND !empty($_GET['rc'])) {

    $rc_infos = $_GET['rc'];

    $selannonces = $bdd->prepare("SELECT * FROM annonces WHERE titre LIKE ? ORDER BY date DESC LIMIT 0,30");
    $selannonces->execute(array("%$rc_infos%"));
    $selannonces_row = $selannonces->rowCount();

} else {

    $selannonces = $bdd->query("SELECT * FROM annonces ORDER BY date DESC LIMIT 0,30");
    $selannonces_row = $selannonces->rowCount();

}

$og_titre = "Annonces";
$og_desc = "Annonces : Toutes vos annonces peuvent etre poster par new informatique 24, il vous suffit de se connecter a votre compte new informatique 24 et de demander l'autorisation par la page de c...";
$og_image = "https://newinformatique24.com/logo.jpg";


?>

<!DOCTYPE html>
<html>
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti, cours, tutoriel">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png"> 

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/cours.css">
    
    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body>
     
    <?php include "inc/header.php" ?>
     
    <div id="c">

        <?php include "inc/menu.php" ?>

        <div id="pr" class="cours">

        <?php if (isset($_SESSION['id_ut'])) {

            $sel_id_ut = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
            $sel_id_ut->execute(array($_SESSION['id_ut']));
            $niv_ut_row = $sel_id_ut->rowCount();
        
            if ($niv_ut_row == 1) {               
                $niv_ut_ft = $sel_id_ut->fetch();
                $niv_ut = $niv_ut_ft['niveau'];
            } else {
                $niv_ut = "0";
            } 
            
            if ($niv_ut >= 1){ ?>

            <div class="editeur">
                <a href="admin/add_annonce.php">
                    <img src="images/items/add.jpg" alt="image d'ajout">
                    <span>Publier</span>
                </a>
            </div>

        <?php }} ?>

            <a class="cours_aff">    
                <div>
                    <h3>Annonces</h3>
                    <p>Toutes vos annonces peuvent etre poster par new informatique 24, il vous suffit de se connecter a votre compte new informatique 24 et de demander l'autorisation par la page de contact</p>
                    <p class="mob">Toutes vos annonces peuvent etre poster par new informatique 24, il vous suffit de se connecter a votre compte new informatique 24 et de demander l'autorisation par la page de contact</p>
                    <p class="date">Annonce</p>
                </div>
            </a>
            <br><br>
        <?php while($annonce = $selannonces->fetch()) {

            $id_nom_ut = $annonce['utilisateur'];
            $sel_nom_ut = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
            $sel_nom_ut->execute(array($id_nom_ut));
            $nom_ut_row = $sel_nom_ut->rowCount();
        
            if ($nom_ut_row == 1) {
                
                $nom_ut_ft = $sel_nom_ut->fetch();
                $nom_ut = $nom_ut_ft['nom'];

            } else {

                $nom_ut = "inconnu";
            }
        
        ?>

            <a href="annonce.php?infos=<?= $annonce['id'] ?>" title="annonce" class="cours_aff"> 
                <div>
                    <h3><?= $annonce['titre'] ?></h3>
                    <p class="date"><?= substr( htmlspecialchars($annonce['texte']), 0, 300) ?> ...</p>
                </div>
            </a>

        <?php } 
          
        if($selannonces_row == 0) { ?>
            <br><br>
            <h2 style="color:white;">Aucune annonce a été trouver !</h2>
            <br><br>
        <?php } ?>

        </div>
    </div>

    <?php include "inc/secondaire.php" ?>

    <?php include "inc/footer.php" ?>

</body>
</html>