<?php
require_once "php/config.php";
require_once "php/connexion.php";

// Verification de l'envoie du formulaire
if (isset($_POST['inscrit'])){

    // Verfification d'envoie de chaque champs du formulaire
    if (!empty($_POST['nom_ut']) AND !empty($_POST['genre_ut']) AND !empty($_POST['pays_ut']) AND !empty($_POST['adr_ut']) AND !empty($_POST['tel_ut'])){

        // Attribution des valeurs aux variables
        $nom = htmlspecialchars($_POST['nom_ut']);
        $genre = htmlspecialchars($_POST['genre_ut']);
        $pays = htmlspecialchars($_POST['pays_ut']);
        $adresse = htmlspecialchars($_POST['adr_ut']);
        $telephone = htmlspecialchars($_POST['tel_ut']);
        $photo = "auto.jpg";
        
        $vr_niv = $bdd->query("SELECT * FROM utilisateurs");
        $vr_niv_row = $vr_niv->rowCount();
        
        if ($vr_niv_row == 0){
            $niv_ut = 1;
        } else {
            $niv_ut = 0;
        }     

        if ($utilisateur_ut_row == 1){

            // enregistrement d'informations sur la table info
            $up_tbl = $bdd->prepare("UPDATE informations SET nom = ?, telephone = ?, sexe = ?, pays = ?, adresse = ? WHERE id_ut = ?");
            $up_tbl->execute(array($nom, $telephone, $genre, $pays, $adresse, $_SESSION['id_ut']));

            header("Location: profil.php?id_utilisateur=" . $_SESSION['id_ut']);

        } else {

            // enregistrement d'informations sur la table info
            $ins_tbl = $bdd->prepare("INSERT INTO informations (id_ut, nom, telephone, sexe, pays, adresse, photo, niveau) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?)");
            $ins_tbl->execute(array($_SESSION['id_ut'], $nom, $telephone, $genre, $pays, $adresse, $photo, $niv_ut));

            header("Location: profil.php?id_utilisateur=" . $_SESSION['id_ut']);
        } 
        
    // Fermeture de la verification de non vide de chaque champs
    } else {
        $msg = "Veuillez remplir les champs completement !";
    }

// Fermeture de la verification d'envoie
}
$og_titre = "New Informatique 24 - Modification Profil";
$og_desc = "Modification de profil : il est obligatoire de tout remplir sur le formulaire ici prese...";
$og_image = "https://newinformatique24.com/logo.jpg";


?>

<!DOCTYPE html>
<html>
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti, cours, tutoriel">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png">  

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/form.css">
    
    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body>
    <header>
         <div class="logo">
             <img src="logo.png" alt="logo de New Inforatique 24">
            <h1>New Informatique <span>24</span></h1>
         </div>
    </header>
    
    <div id="form">
        <form method="post">
            <h3>Modification du profil</h3>
            <p <?php if(isset($msg)) { ?> style=color:red; <?php } ?> >
                <i><?php if(isset($msg)){ echo $msg; } else { ?>Note : il est obligatoire de tout remplir sur le formulaire ici present ! <?php } ?></i>
            </p>
            <p class="cap">Nom Complet</p>
            <input type="text" name="nom_ut" placeholder="Votre Nom" value="<?= $nom_ut ?>" required>
            <p class="cap">Genre (sexe)</p>
            <select name="genre_ut">
                <option value="<?= $sexe_ut ?>"><?= $sexe_ut ?></option>
                <option value="homme">Homme</option>
                <option value="femme">Femme</option>
            </select>
            <p class="cap">Pays</p>
            <input type="text" name="pays_ut" placeholder="Votre pays" value="<?= $pays_ut ?>" required>
            <p class="cap">Adresse physique</p>
            <input type="text" name="adr_ut" placeholder="Votre adresse" value="<?= $adresse_ut ?>" required>
            <p class="cap">Telephone</p>
            <input type="text" name="tel_ut" placeholder="Votre telephone" value="<?= $tel_ut ?>" required>
            
            <div class="btn">
                <a href="profil.php?id_utilisateur=<?= $_SESSION['id_ut'] ?>">Annuler</a>
                <input type="submit" value="Enregistrer" name="inscrit">   
            </div>      
        </form>
    </div>

    <?php include "inc/footer.php" ?>
</body>
</html>