<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-JBKZDMLQWB"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-JBKZDMLQWB');
</script>

<!-- Google Adsense -->
<script data-ad-client="ca-pub-1683150263600532" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>