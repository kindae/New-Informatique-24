    <footer>
        <div class="a">
            <div>
                <img src="logo.png" alt="logo de new informatique 24">
            </div>
            
            <div>
                <h2>Menu Secodaire</h2>
                <a href="accueil">Accueil</a>
                <a href="contact">Contactes-nous</a>
                <a href="apropos">A propos de nous</a>
                <a href="confidentialite" target="_blank">Reglement de confidentialité</a>
                <a href="non_responsabilite.php" target="_blank">Clause de non-responsabilité</a>
            </div>
        </div>
        <div class="b">
            <p>Copyright 2020 - 2025 | All right reserved New Informatique 24 design by FMH STUDIO</p>
        </div>
    </footer>