<?php

if(isset($_POST['rc_btn'])){
    if(!empty($_POST['rc'])){

        header("Location: recherche.php?rc=" . $_POST['rc']);

    } else {

        header("Location: recherche.php");

    }
}

?>

    <script src="js/nav.js"></script>
    <header>
         <div class="logo">
             <img src="logo.png" alt="logo de New Inforatique 24">
            <h1>New Informatique <span>24</span></h1>
         </div>
         
         <form method="post" class="rc" action="recherche.php">
            <input type="search" name="rc" placeholder="Recherche" value="<?php if(isset($_GET['rc']) AND !empty($_GET['rc'])){ echo $_GET['rc'];} ?>">
            <input type="submit" value="Recherche" name="rc_btn">
         </form>
     </header>
     <span class="open" id="openmenu" onclick="openNav()">menu</span>
     <span class="close" id="closemenu" onclick="closeNav()">X</span>