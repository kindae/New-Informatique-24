 <?php

$selcours_sc = $bdd->query("SELECT * FROM cours ORDER BY date_cours DESC LIMIT 0,5");
$selcours_sc_row = $selcours_sc->rowCount();

$seltutos_sc = $bdd->prepare("SELECT * FROM tutoriels WHERE actif_tuto = ? ORDER BY date_ed_tuto DESC LIMIT 0,5");
$seltutos_sc->execute(array(0));
$seltutos_sc_row = $seltutos_sc->rowCount();

$selpub_sc = $bdd->query("SELECT * FROM annonces ORDER BY date DESC LIMIT 0,5");
$selpub_sc_row = $selpub_sc->rowCount();

?>

    <div id="sc">
        <div>
            <h2>News Cours</h2>
            <ul>
                <?php while($cours_sc = $selcours_sc->fetch()) { ?>

                <li>
                    <a href="cours.php?infos=<?= $cours_sc['id_cours'] ?>"><?= $cours_sc['nom_cours']; ?></a>
                </li>

                <?php } if($selcours_sc_row == 0) { ?>

                <li>
                    <a>Pas de cours ajouter !</a>
                </li>

                <?php } ?>
            </ul>
        </div>
        <div>
            <h2>News Tutoriels</h2>
            <ul>
            
                <?php while($tutos_sc = $seltutos_sc->fetch()) { ?>

                <li>
                    <a href="tutoriel.php?tuto=<?= $tutos_sc['id_tuto'] ?>">
                        <?= $tutos_sc['titre_tuto']; ?>
                        <span><?= substr(htmlspecialchars($tutos_sc['contenu_tuto']), 0, 30) ?> ...</span>
                    </a>
                </li>

                <?php } if($seltutos_sc_row == 0) { ?>

                <li>
                    <a>Pas de tutoriel ajouter !</a>
                </li>

                <?php } ?>
        
            </ul>
        </div>
        <div>
            <h2>News Annonces</h2>
            <ul>
                
                <?php while($pub_sc = $selpub_sc->fetch()) { ?>

                <li>
                    <a href="annonce.php?infos=<?= $pub_sc['id'] ?>">
                        <?= $pub_sc['titre'] ?>
                        <span><?= substr(htmlspecialchars($pub_sc['texte']), 0, 30) ?> ...</span>    
                    </a>
                </li>

                <?php } if($selpub_sc_row == 0) { ?>

                <li>
                    <a>Pas de publication ajouter !</a>
                </li>

                <?php } ?>

            </ul>
        </div>
     </div>