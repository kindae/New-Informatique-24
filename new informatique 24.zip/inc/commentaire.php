<?php
require_once "php/config.php";

if(isset($_POST['envoyer'])){

    if(!empty($_POST['commentaire'])){

        $commentaire = $_POST['commentaire'];

        $ins_tbl = $bdd->prepare("INSERT INTO commentaires (id_ut, id_pub, contenu) VALUES (?, ?, ?)");
        $ins_tbl->execute(array($_SESSION['id_ut'], $_GET['tuto'], $commentaire));
    }
}

$vrcom = $bdd->prepare("SELECT * FROM commentaires WHERE id_pub = ?");
$vrcom->execute(array($_GET['tuto']));
$vrcom_row = $vrcom->rowCount();

if (isset($_GET['page']) AND !empty($_GET['page'])){

    $pageseld = ($_GET['page'] - 1)*10;
    $parpages = 10;
    $psel = $pageseld . "," . $parpages;

    $selcom = $bdd->prepare("SELECT * FROM commentaires WHERE id_pub = ? ORDER BY date DESC LIMIT " . $psel);
    $selcom->execute(array($_GET['tuto']));
    $selcom_row = $selcom->rowCount();

} else {

    $selcom = $bdd->prepare("SELECT * FROM commentaires WHERE id_pub = ? ORDER BY date DESC LIMIT 0,10");
    $selcom->execute(array($_GET['tuto']));
    $selcom_row = $selcom->rowCount();

}

?>

<style>
.comm{
    display:flex;
    align-items: center;
    margin: 20px 0;
}
.comm textarea{
    display: block;
    width: 600px;
    height: 70px;
    padding:10px;
    font-size: 14px;
    border-radius:14px;
}
.comm input[type=submit]{
    display: block;
    width: 100px;
    padding: 10px;
    margin:10px;
    height: 40px;
    font-size: 12px;
    border-radius:14px;
    background: #0050ff;
    color: #fff;
    cursor: pointer;
}

.dc{
    border-bottom: 1px solid #999;
    color:#999;
    text-align:center;
    padding: 5px;
    margin: 5px;
    font-size: 14px;
}
.commentaires{
    border-radius: 15px;
    background: #0050ff;
    width: 400px;
    padding: 5px;
    margin: 10px 0;
    color: #fff;
}
.commentaires p.nom{
    border-bottom: 1px solid #999;
}
.commentaires p{
    font-size: 14px;
    color: #fff;
    padding:5px;
}
@media (max-width: 920px){
    .comm{
        display:block;
    }
    .comm textarea{
        display: block;
        width: 90%;
        height: 30px;
        padding: 10px;
        font-size: 12px;
        border-radius:14px;
        margin: 5px auto;
    }
    .comm input[type=submit]{
        padding: 5px;
        margin: 5px auto;
        height: 40px;
        font-size: 12px;
        border-radius:12px;
    }

    .dc{
        font-size: 12px;
    }
    .commentaires{
        width: 90%;
        padding: 5px;
        margin: 10px auto;
    }
    .commentaires p{
        font-size: 12px;
        color: #fff;
        padding:5px;
    }
}
</style>

<br><br>
<p class="dc">partie commentaire</p>

<?php if (isset($_SESSION['id_ut'])) { ?>

<form class="comm" method="post">
    <textarea name="commentaire" placeholder="commentaire..."></textarea>
    <input type="submit" value="commenter" name="envoyer">
</form>

<?php }

while($pub = $selcom->fetch()) {

$id_nom_ut = $pub['id_ut'];
$sel_nom_ut = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
$sel_nom_ut->execute(array($id_nom_ut));

$nom_ut_row = $sel_nom_ut->rowCount();

if ($nom_ut_row == 1) {
    
    $nom_ut_ft = $sel_nom_ut->fetch();
    $nom_ut = $nom_ut_ft['nom'];

} else {

    $nom_ut = "inconnu";
}

?>

<p class="dc"><?= date("d/m/Y H:i",strtotime($pub['date'])) ?></p>
<div class="commentaires">
    <p class="nom"><?= $nom_ut ?></p>
    <p><?= nl2br($pub['contenu']); ?></p>
</div>

<?php } ?>

<div class="pagination">

<?php $pagespub = $vrcom_row / 10;

if(isset($_GET['page']) AND !empty($_GET['page'])){

    if ($pagespub > $_GET['page']) { $pap = $_GET['page'] - 1; $pas = $_GET['page'] + 1;?>

        <a href="tutoriel.php?tuto=<?= $_GET['tuto']?>&page=<?= $pap ?>">Precedente</a>
        <a href="tutoriel.php?tuto=<?= $_GET['tuto']?>&page=<?= $pas ?>">Suivante</a>

    <?php } else { $pap = $_GET['page'] - 1; ?>

        <a href="tutoriel.php?tuto=<?= $_GET['tuto']?>&page=<?= $pap ?>">Precedente</a>
        <a class="inactive">Suivante</a>

    <?php }

} else {

    if ($vrcom_row > 10) { ?>

        <a class="inactive">Precedente</a>
        <a href="tutoriel.php?tuto=<?= $_GET['tuto']?>&page=2">Suivante</a>

<?php } } ?>

</div>