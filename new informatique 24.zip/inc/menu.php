        <nav id="menunav">
            <ul>
                <li><a></a></li>
                <h2>Menu Navigation</h2>
                <li><a href="accueil">Accueil</a></li>
                <li><a href="cours_list.php">Cours</a></li>
                <li><a href="tutoriels">Tutoriels</a></li>
                <li><a href="dico">Dico-wiki</a></li>
                <li><a href="annonces.php">Annonces</a></li>
                <h2>Partie Abonnée</h2>
                <style>
                    span.r{
                        background: red;
                        font-size: 14px;
                        color: #fff;
                        padding: 4px;
                    }
                </style>
                <?php if (isset($_SESSION['id_ut'])) { 

                $vr_msg = $bdd->prepare("SELECT * FROM message WHERE vu = ? AND (ut = ? OR utd = ?)");
                $vr_msg->execute(array($_SESSION['id_ut'], $_SESSION['id_ut'], $_SESSION['id_ut']));
                $vr_msg_r = $vr_msg->rowCount();
                
                ?>
                <li><a href="profil.php?id_utilisateur=<?= $_SESSION['id_ut'] ?>">Profil</a></li>
                <li><a href="message/">Messages <?php if($vr_msg_r > 0){?><span class="r"><?= $vr_msg_r ?></span><?php } ?></a></li>

                <?php
                $vr_user_niv = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
                $vr_user_niv->execute(array($_SESSION['id_ut']));
                $vr_user_niv_ft = $vr_user_niv->fetch();
                $user_niv = $vr_user_niv_ft['niveau'];

                if($user_niv > 0){ ?>

                <li><a href="admin/">administration</a></li>

                <?php }
                    } else { ?>
                <li><a href="inscription.php">Inscription</a></li>
                <li><a href="connexion.php">Connexion</a></li>
                <?php } ?>
                <h2>Partie Information</h2>
                <li><a href="apropos">A propos de nous</a></li>
                <li><a href="contact">Contactez-nous</a></li> 
            </ul>
        </nav>