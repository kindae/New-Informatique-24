<?php
require_once "php/config.php";

if (isset($_GET['cours']) AND !empty($_GET['cours'])){

    $vrcours = $bdd->prepare("SELECT * FROM cours WHERE id_cours = ? AND actif_cours = ?");
    $vrcours->execute(array($_GET['cours'], "0"));
    $vrcours_row = $vrcours->rowCount();

    if($vrcours_row == 1){

        $cours = $vrcours->fetch();
        $nom_cours = $cours['nom_cours'];
        $desc_cours = $cours['desc_cours'];
        $image_cours = $cours['image_cours'];

        $selchap = $bdd->prepare("SELECT * FROM chapitres WHERE id_cours = ? ORDER BY date_chap DESC");
        $selchap->execute(array($_GET['cours']));
        $selchap_row = $selchap->rowCount();

    } else {
        header("Location: cours.php");
    }
} else {
    header("Location: cours.php");
}

$og_titre = "New Informatique 24 - " . $nom_cours;
$og_desc = substr($desc_cours, 0, 150);
$og_image = "https://newinformatique24.com/images/cours/" . $image_cours;

?>

<!DOCTYPE html>
<html>
<head>    
    
    <?php require "inc/head.php" ?>


    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/cours.css">
</head>
<body>
     
    <?php include "inc/header.php" ?>
     
    <div id="c">

        <?php include "inc/menu.php" ?>

        <div id="pr" class="cours">

        <?php if (isset($_SESSION['id_ut'])) { 

            if ($_SESSION['id_ut'] == 1) { ?>

                <div class="editeur">
                <a href="admin/add_cours.php">
                    <img src="images/items/add.jpg" alt="image d'ajout">
                    <span>Ajouter un chapitre</span>
                </a>
                </div>

        <?php } else { ?>

                <div class="editeur">
                    <a>
                        <p>vous n'etes pas autoriser a modifier ce cours</p>
                    </a>
                </div>

        <?php }
        } else { ?>

            <div class="editeur">
                <a>
                    <p>Vous etes au choix des chapitres</p>
                </a>
            </div>
            
        <?php } ?>

            <a href="tutoriels.php?cours=<?= $_GET['cours'] ?>" class="cours_aff">    
                <div>
                    <h3>Tutoriels</h3>
                    <p>Les tutoriels ici sont relier aux cours present pour vous depanner dans d'autre points important sur le cours (bien que cela n'est pas obligatoire mais il peut vous etre utile dans certains points) !</p>
                    <p class="mob">Les tutoriels ici sont relier aux cours present pour vous depanner dans d'autre points !</p>
                    <p class="date">Hors le cours</p>
                </div>
            </a>

        <?php while($chap = $selchap->fetch()) { ?>

            <a href="chapitre.php?cours=<?= $chap['id_chap'] ?>" title="titre_chap" class="chap_aff"> 
                <div>
                    <h3><?= $chap['titre_chap'] ?></h3>
                    <p class="date"><?= date("d F Y, H:i",strtotime($chap['date_chap'])) ?></p>
                </div>
            </a>

        <?php } 
          
        if($selchap_row == 0) { ?>
            <br><br>
            <h2 style="color:white;">Aucun chapitre a été ajouter !</h2>
            <br><br>
        <?php } ?>

        </div>
    </div>

    <?php include "inc/secondaire.php" ?>

    <?php include "inc/footer.php" ?>

</body>
</html>