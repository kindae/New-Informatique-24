<?php
require_once "php/config.php";

$og_titre = "A propos de nous";
$og_desc = "Creer en 2017 par Henry FITI, New informatique 24 est une entreprise en ligne sur la formation informatique, avec comme but principale, la formation sur le domaine l'informatique...";
$og_image = "https://newinformatique24.com/logo.jpg";


?>

<!DOCTYPE html>
<html>
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="apropos, Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png">

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/styles_sc.css">

    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body>
     
    <header>
        <a href="accueil" class="title">
            <img src="logo.png" alt="logo new informatique 24">
            <span>New Informatique 24</span>
        </a>

        <a href="accueil" class="btn">Retour</a>
    </header>
    <div class="aff_text">
        <div class="titre">
            <h1>A propos de nous</h1>
            <p>
                Ce qui suit represente des données et informations fournis par New Informatique 24 !
            </p>
        </div>
        <div class="list">
            <h2>General</h2>
            <p>
                Creer en 2017 par Henry FITI, New informatique 24 est une entreprise en ligne sur la formation informatique, avec comme but principale, la formation sur le domaine l'informatique.
                <br><br>

            </p>
        </div>
        <div class="list">
            <h2>Qu'apprendrez-vous sur New Informatique ?</h2>
            <p>
                Vous trouverez des ressources sur :
                <br><br>

                <ul>
                    <li>Des cours sur le domaine informatique</li>
                    <li>Des tutoriels présentant une tâche précise et initiant sur la façon de l'accomplir</li>
                    <li>Des explications sur differents mots du jargon informatique</li>
                </ul>
            </p>
        </div>
        <div class="list">
            <h2>Partenaires</h2>
            <p>
                Partenaire dans ce page web est celui qui s'associe à New Informatique 24, que ça soit en matiere d'aide financiere, convention, idée ou autres qui a rapport a New Informatique 24, ce dernier est considere comme partenaire.
                <br><br>

                Nous avons comme partenaires :
                <br><br>

                <ul>
                    <li>Stia Monde 24</li>
                    <li>FMH STUDIO</li>
                </ul>
            </p>
        </div>
        <div class="list">
            <h2>Responsable du traitement de données</h2>
            <p>
                FITI MBENZA henry, congolais de la Republique Democratique du Congo
                <br><br>

                Avenue : Bateke, 6D
                <br>
                Matete / Mont-Amba
                <br>
                Ville : Kinshasa
                <br><br>

                Facebook : Henry Fiti
                <br>
                Instagram : henry_fiti1
                <br>
                Telephone : +243 (0) 82 93 47 920
                <br>
                Email : henryfiti1@gmail.com
            </p>
        </div>
        <div class="list">
            <h2>Copyright images</h2>
            <p>
                newInformatique24.com
            </p>
        </div>
        <nav>
            <a href="accueil">Accueil</a>
            <a href="apropos">A propos de nous</a>
            <a href="contact">Contactez-nous</a>
            <a href="confidentialite" target="_blank" rel="noopener noreferrer">Politique de confidentialité</a>
            <a href="non_responsabilite.php" target="_blank" rel="noopener noreferrer">Clause de non-resposabilité</a>
        </nav>
    </div>

    <footer>
        <p>Copyright &copy; - New Informatique 24</p>
    </footer>  
</body>
</html>