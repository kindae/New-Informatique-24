<?php
require_once "php/config.php";

$vrmots = $bdd->prepare("SELECT * FROM dico WHERE actif_mot = ?");
$vrmots->execute(array("0"));
$vrmots_row = $vrmots->rowCount();

if (isset($_GET['page']) AND !empty($_GET['page'])){

    $pageseld = ($_GET['page'] - 1)*50;
    $parpages = 50;
    $psel = $pageseld . "," . $parpages;

    $selmots = $bdd->prepare("SELECT * FROM dico WHERE actif_mot = ? ORDER BY mot ASC LIMIT " . $psel);
    $selmots->execute(array("0"));
    $selmots_row = $selmots->rowCount();

} elseif(isset($_GET['rc']) AND !empty($_GET['rc'])) {

    $rc_infos = $_GET['rc'];

    $selmots = $bdd->prepare("SELECT * FROM dico WHERE actif_mot = ? AND mot LIKE ? ORDER BY mot ASC LIMIT 0,100");
    $selmots->execute(array("0", "%$rc_infos%"));
    $selmots_row = $selmots->rowCount();

} else {

    $selmots = $bdd->prepare("SELECT * FROM dico WHERE actif_mot = ? ORDER BY mot ASC LIMIT 0,50");
    $selmots->execute(array("0"));
    $selmots_row = $selmots->rowCount();

}

$og_titre = "Dico-Wiki";
$og_desc = "Dico - wiki : Tout le monde a droit d'ajouter un mot du jargon informatique, il vous suffit de se connecter a votre compte new informatique 24 et de demander l'autorisation par la page de c...";
$og_image = "https://newinformatique24.com/logo.jpg";


?>

<!DOCTYPE html>
<html>
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti, cours, tutoriel">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png"> 

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/cours.css">
    
    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body>
     
    <?php include "inc/header.php" ?>
     
    <div id="c">

        <?php include "inc/menu.php" ?>

        <div id="pr" class="cours">

        <?php if (isset($_SESSION['id_ut'])) {

            $sel_id_ut = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
            $sel_id_ut->execute(array($_SESSION['id_ut']));
            $niv_ut_row = $sel_id_ut->rowCount();
        
            if ($niv_ut_row == 1) {               
                $niv_ut_ft = $sel_id_ut->fetch();
                $niv_ut = $niv_ut_ft['niveau'];
            } else {
                $niv_ut = "0";
            } 
            
            if ($niv_ut >= 1){ ?>

            <div class="editeur">
                <a href="admin/add_mot.php">
                    <img src="images/items/add.jpg" alt="image d'ajout">
                    <span>Proposer un mot</span>
                </a>
            </div>

        <?php }} ?>

            <a class="cours_aff">    
                <div>
                    <h3>Dico - wiki</h3>
                    <p>Tout le monde a droit d'ajouter un mot du jargon informatique, il vous suffit de se connecter a votre compte new informatique 24 et de demander l'autorisation par la page de contact</p>
                    <p class="mob">Tout le monde a droit d'ajouter un mot du jargon informatique, il vous suffit de se connecter a votre compte new informatique 24 et de demander l'autorisation par la page de contact</p>
                    <p class="date">Annonce</p>
                </div>
            </a>
            <br><br>
        <?php while($mot = $selmots->fetch()) {

            $id_nom_ut = $mot['ut_mot'];
            $sel_nom_ut = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
            $sel_nom_ut->execute(array($id_nom_ut));
            $nom_ut_row = $sel_nom_ut->rowCount();
        
            if ($nom_ut_row == 1) {
                
                $nom_ut_ft = $sel_nom_ut->fetch();
                $nom_ut = $nom_ut_ft['nom'];

            } else {

                $nom_ut = "inconnu";
            }
        
        ?>

            <a href="mot.php?infos=<?= $mot['id_mot'] ?>" title="mot" class="cours_aff"> 
                <div>
                    <h3><?= $mot['mot'] ?></h3>
                    <p class="date"><?= $nom_ut ?> : <?= substr( htmlspecialchars($mot['desc_mot']), 0, 250) ?> ...</p>
                </div>
            </a>

        <?php } 
          
        if($selmots_row == 0) { ?>
            <br><br>
            <h2 style="color:white;">Aucun mot a été trouver !</h2>
            <br><br>
        <?php } ?>

        <?php if(!isset($rc_infos)){ ?>

            <div class="pagination">

            <?php $pagesmots = $vrmots_row / 50;

            if(isset($_GET['page']) AND !empty($_GET['page'])){

                if ($pagesmots > $_GET['page']) { $pap = $_GET['page'] - 1; $pas = $_GET['page'] + 1;?>

                <a href="dico.php?page=<?= $pap ?>">Precedente</a>
                <a href="dico.php?page=<?= $pas ?>">Suivante</a>

                <?php } else { $pap = $_GET['page'] - 1; ?>

                <a href="dico.php?page=<?= $pap ?>">Precedente</a>
                <a class="inactive">Suivante</a>

                <?php }

            } else {

                if ($vrmots_row > 50) { ?>

                <a class="inactive">Precedente</a>
                <a href="dico.php?page=2">Suivante</a>

            <?php } } ?>

            </div>

        <?php } ?>
        </div>
    </div>

    <?php include "inc/secondaire.php" ?>

    <?php include "inc/footer.php" ?>

</body>
</html>