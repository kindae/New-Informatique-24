<?php
require_once "../php/config.php";
require_once "../php/connexion.php";

// Verification de l'envoie du formulaire
if (isset($_POST['pub']) AND !empty($_POST['titre']) AND !empty($_POST['lien'])){

    $vrtt = $bdd->query("SELECT * FROM tutoriels");
    $vrtt_row = $vrtt->rowCount() + 1;

    $dossier = "../images/tuto/";

    if(isset($_FILES['image_tuto']['tmp_name']) AND !empty($_FILES['image_tuto']['tmp_name'])){
        $nom_img = $vrtt_row . "img.jpg";
        $fichier = $dossier . $nom_img;
        move_uploaded_file($_FILES['image_tuto']['tmp_name'], $fichier);
    }
    if(isset($_FILES['image_tuto1']['tmp_name']) AND !empty($_FILES['image_tuto1']['tmp_name'])){
        $nom_img1 = $vrtt_row . "img1.jpg";
        $fichier1 = $dossier . $nom_img1;
        move_uploaded_file($_FILES['image_tuto1']['tmp_name'], $fichier1);
    }
    if(isset($_FILES['image_tuto2']['tmp_name']) AND !empty($_FILES['image_tuto2']['tmp_name'])){
        $nom_img2 = $vrtt_row . "img2.jpg";
        $fichier2 = $dossier . $nom_img2;
        move_uploaded_file($_FILES['image_tuto2']['tmp_name'], $fichier2);
    }
    if(isset($_FILES['image_tuto3']['tmp_name']) AND !empty($_FILES['image_tuto3']['tmp_name'])){
        $nom_img3 = $vrtt_row . "img3.jpg";
        $fichier3 = $dossier . $nom_img3;
        move_uploaded_file($_FILES['image_tuto3']['tmp_name'], $fichier3);
    }

    $titre = $_POST['titre'];
    $lien = $_POST['lien'];
    $text = $_POST['text'];
    $text1 = $_POST['text1'];
    $text2 = $_POST['text2'];
    $text3 = $_POST['text3'];

    if(isset($nom_img)){
        $img = $nom_img;
    } else {
        $img = "auto.jpg";
    }

    if(isset($nom_img1)){
        $img1 = "<img src=\"images/tuto/" . $nom_img1 ."\">";
    } else {
        $img1 = "";
    }

    if(isset($nom_img2)){
        $img2 = "<img src=\"images/tuto/" . $nom_img2 ."\">";
    } else {
        $img2 = "";
    }

    if(isset($nom_img3)){
        $img3 = "<img src=\"images/tuto/" . $nom_img3 ."\">";
    } else {
        $img3 = "";
    }
    
    $contenu = ($text . "\r\n \r\n" . $img1 . "\r\n" . $text1 . "\r\n \r\n" . $img2 . "\r\n" . $text2 . "\r\n \r\n" . $img3 . "\r\n" . $text3);

    $instotuto = $bdd->prepare("INSERT INTO tutoriels(titre_tuto, id_ut, actif_tuto, lien_ext_tuto, image_tuto, contenu_tuto) VALUES (?, ?, ?, ?, ?, ?)");
    $instotuto->execute(array($titre, $_SESSION['id_ut'], "0", $lien, $img, $contenu));

    // message
    
    ini_set('display_errors', 1);
    error_reporting( E_ALL );

    $selmailut = $bdd->query("SELECT * FROM utilisateurs");

    while($a = $selmailut->fetch()) { 

        $destinataires = ($a['user_ut']);
            
        $sujet = "Nouveau tutoriel sur new informatique 24";

        // en-têtes expéditeur
        $entetes= "From : \"New Informatique 24\"<notification@newinformatique24.com>\n";

        // en-têtes adresse de retour
        $entetes .= "Reply-to : henryfiti1@gmail.com\n";

        // priorité urgente
        $entetes .= "X-Priority : 1\n";

        $message =
            "
                New Informatique 24 Notification en Francais : \r\n \r\n
            
                Un nouveau tutoriel lancer qui pourrais vous être utile dans le site New Informatique 24. pour plus d'infos, aller sur : https://www.newinformatique24.com/tutoriel.php?tuto=" . $vrtt_row . "

                \r\n \r\n
                La gestion de messagerie Monsieur Henry FITI avec son adresse mail : Henryfiti1@gmail.com !

                \r\n \r\n
                Envoyez par : New Informatique 24 \r\n
                Date de reception : " . date('d-m-Y') . " \r\n
                Site : newinformatique24.com \r\n
            ";

        mail($destinataires, $sujet, $message, $entetes);
    }

    header("Location: ../tutoriel.php");

// Fermeture de la verification d'envoie
}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="alternate" href="../rss.php" type="application/rss+xml" title="tutoriels">
    <title>Administration - New informatique 24</title>
    <meta name="description" content="Apprendre l'inforatique en quelque jours avec New Inforatique. Nous avons les tutoriels et les cours, les cours sont en ligne et sureveiller 100% donc venez faire l'epreuve de la science.">
    <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="../apple-touch-icon.png">
    <link rel="mask-icon" href="../logo.png" color="#5bbad5">
    <link rel="manifest" href="../site.webmanifest">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/header.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="../css/form.css">
    <script data-ad-client="ca-pub-1683150263600532" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
</head>
<body id="conn">
    <header>
         <div class="logo">
             <img src="../logo.png" alt="logo de New Inforatique 24">
            <h1>New Informatique <span>24</span></h1>
         </div>
     </header>

    <div id="form">
        <form method="post" enctype="multipart/form-data">
            <h3>Publication tuto</h3>
            <p <?php if(isset($msg)) { ?> style=color:red; <?php } ?> >
                <i><?php if(isset($msg)){ echo $msg; } else { ?>Note : il est obligatoire de tout remplir sur le formulaire ici present ! <?php } ?></i>
            </p>
            <p class="cap">titre</p>
            <input type="text" name="titre" placeholder="Titre" require>
            <p class="cap">lien video</p>
            <input type="text" name="lien" placeholder="lien" require>
            <p class="cap">image du tuto</p>
            <input type="file" name="image_tuto" placeholder="lien" require>

            <p class="cap">1er partie</p>
            <textarea name="text" rows="10" placeholder="1e partie" require>...</textarea>
            
            <p class="cap">1er partie image</p>
            <input type="file" name="image_tuto1" require>

            <p class="cap">2e partie</p>
            <textarea name="text1" rows="10" placeholder="2e partie" require>...</textarea>

            <p class="cap">2er partie image</p>
            <input type="file" name="image_tuto2" require>

            <p class="cap">3e partie</p>
            <textarea name="text2" rows="10" placeholder="3e partie" require>...</textarea>

            <p class="cap">3e partie image</p>
            <input type="file" name="image_tuto3" require>

            <p class="cap">fin partie</p>
            <textarea name="text3" rows="10" placeholder="Fin partie" require>...</textarea>
            
            <div class="btn">
                <a href="../">retour</a>
                <input type="submit" value="Publier" name="pub">   
            </div>      
        </form>
    </div>
</body>
</html>