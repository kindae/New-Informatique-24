<?php
require_once "../php/config.php";
require_once "../php/connexion.php";

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration - New informatique 24</title>
</head>
<body>
    <div id="body">
        <h2>Administration</h2>
        <a href="">Statistiques</a>
        <a href="">Administrateurs</a>
        <a href="">Moderateurs</a>
        <a href="">Utilisateurs vip</a>
        <a href="">Utilisateurs</a>
        <a href="cours.php">Cours</a>
        <a href="">Tutoriels</a>
        <a href="">Dico-wiki</a>
        <a href="">Annonces</a>
        <a href="citations.php">Citations</a>
        <a href="">Commentaires</a>
        <a href="../">Retour sur le site</a>
        <span>&copy; Kinda-e by geekcold</span>
    </div>
    <div class="img">
        <img src="img/logo.png">
    </div>
    

    <style type="text/css">
        *{
            padding: 0;
            margin: 0;
            font-family: arial;
        }
        body{
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        #body{
            width: 360px;

        }
        h2{
            font-size: 21px;
            text-align: center;
            color: #33aaff;
            padding: 10px;
        }
        a{
            display: block;
            font-size: 16px;
            color: #333;
            padding: 10px;
            margin: 5px;
            background-color: #eee;
            text-decoration: none;
            border-radius: 2px;
        }
        span{
            display: block;
            color: #ccc;
            font-size: 15px;
            padding: 10px;
            margin: 10px;
        }
        .img{
            width: 100%;
        }
        img{
            display: block;
            margin: 10px auto;
            width: 300px;
        }

        @media (max-width: 920px){
            body{
                display: block;
            }
            #body{
                width: auto;
            }
            h2{
                font-size: 18px;
                padding: 7px;
            }
            a{
                display: block;
                font-size: 14px;
                padding: 8px;
                margin: 3px 5px;
                border-radius: 5px;
            }
            span{
                font-size: 13px;
                padding: 8px;
                margin: 8px;
            }
            .img{
                display: none;
            }
        }
    </style>
</body>
</html>