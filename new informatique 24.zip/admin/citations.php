<?php
require_once "../php/config.php";
require_once "../php/connexion.php";

$select_all = $bdd->query("SELECT * FROM citations LIMIT 0,50");
$select_all_row = $select_all->rowCount();

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration - New informatique 24</title>
</head>
<body>
    <div id="body">
        <header>
            <h2><img src="img/logo.png"> Kinda-e - Administration</h2>
            <span>Citations</span>
        </header>

        <div id="div">
            <form method="get" class="recherche">
                <input type="search" name="search" placeholder="recherche">
                <input type="submit" name="btn">
            </form>
        </div>
        
        <div class="citations">
            <a href="citation.php">Ajouté une citation</a>

            <?php while($cit_fetch = $select_all->fetch()){ ?>

            <a href=""><?= substr( htmlspecialchars($cit_fetch['texte']), 0, 30) ?> ...</a>

            <?php } ?>

        </div>   
            
        <div id="div">
            <div class="pagination">
                
            </div>
        </div>
            
        <span class="copy">&copy; Kinda-e by geekcold</span>
    </div>

    <style type="text/css">
        *{
            padding: 0;
            margin: 0;
            font-family: arial;
        }
        body{
            background-color: #ccc;
        }
        header{
            background-color: #fff;

            padding: 10px 0;
        }
        header h2{
            display: flex;
            align-items: center;
            font-size: 20px;
            color: #0080ff;
            padding: 5px 10px;
        }
        header img{
            display: block;
            width: 32px;
            padding-right: 5px;
        }
        header span{
            display: block;
            padding: 5px 10px;
            color: #777;
            font-size: 16px;    
        }
        #div{
            margin: 10px;
            background-color: #fff;
            border-radius: 3px;
        }
        .recherche{
            display: flex;
            align-items: center;
        }
        .recherche input[type=search]{
            color: #333;
            background-color: transparent;
            border: 1px solid #0080ff;
            font-size: 14px;
            padding: 7px;
            margin: 7px;
            width: 300px;
        }
        .recherche input[type=submit]{
            color: #fff;
            font-size: 14px;
            background-color: #0080ff;
            border: none;
            padding: 7px;
            width: 100px;
            margin: 0;
        }
        .citations{
           display: block;
           padding: 10px;
        }
        .citations a{
            display: inline-block;
            width: 120px;
            text-align: center;
            background-color: #f1f1f1;
            color: #0080ff;
            font-size: 15px;
            text-decoration: none;
            vertical-align: top;
            height: 100px;
            padding: 10px;
            margin-right: 5px;
            align-self: center;
            border: 2px solid #fff;
            border-radius: 5px;

        }
        .copy{
            display: block;
            font-size: 15px;
            color: #333;
            text-align: right;
            padding: 10px;
        }
        @media (max-width: 920px){
            header{
                padding: 5px 0;
            }
            header h2{
                font-size: 17px;
                padding: 5px 7px;
            }
            header img{
                width: 24px;
            }
            header span{
                display: block;
                padding: 5px 7px;
                font-size: 15px;    
            }
            #div{
                margin: 5px;
                border-radius: 2px;
            }
            .recherche input[type=search]{
                color: #333;
                background-color: transparent;
                border: 1px solid #0080ff;
                font-size: 13px;
                padding: 5px;
                margin: 5px;
                width: 80%;
            }
            .recherche input[type=submit]{
                color: #fff;
                font-size: 13px;
                padding: 5px;
                width: 80px;
                margin-right: 5px;
            }
            .citations{
               display: block;
               padding: 5px;
               text-align: justify;
            }
            .citations a{
                display: inline-block;
                width: 70px;
                font-size: 14px;
                height: 80px;
                padding: 7px;
            }
            .copy{
                display: block;
                font-size: 13px;
            }
        }
    </style>
</body>
</html>