<?php
require_once "../php/config.php";
require_once "../php/connexion.php";

// Verification de l'envoie du formulaire
if (isset($_POST['pub']) AND !empty($_POST['contenu']) AND !empty($_POST['titre'])){

    $vrtt = $bdd->query("SELECT * FROM annonces");
    $vrtt_row = $vrtt->rowCount() + 1;

    $dossier = "../images/annonces/";

    if(isset($_FILES['image_pub']['tmp_name']) AND !empty($_FILES['image_pub']['tmp_name'])){
        $nom_img = $vrtt_row . ".jpg";
        $fichier = $dossier . $nom_img;
        move_uploaded_file($_FILES['image_pub']['tmp_name'], $fichier);
        $image_pub = $nom_img;
    } else {
        $image_pub = "auto.jpg";
    }
    $id_ut = $_SESSION['id_ut'];
    $contenu = $_POST['contenu'];
    $titre = $_POST['titre'];
    
    $inspub = $bdd->prepare("INSERT INTO annonces(utilisateur, titre, texte, image) VALUES (?, ?, ?, ?)");
    $inspub->execute(array($id_ut, $titre, $contenu, $image_pub));

    header("Location: ../annonce.php?infos=" . $vrtt_row);
     
// Fermeture de la verification d'envoie
}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="alternate" href="../rss.php" type="application/rss+xml" title="tutoriels">
    <title>Administration - New informatique 24</title>
    <meta name="description" content="Apprendre l'inforatique en quelque jours avec New Inforatique. Nous avons les tutoriels et les cours, les cours sont en ligne et sureveiller 100% donc venez faire l'epreuve de la science.">
    <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="../apple-touch-icon.png">
    <link rel="mask-icon" href="../logo.png" color="#5bbad5">
    <link rel="manifest" href="../site.webmanifest">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/header.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="../css/form.css">
    <script data-ad-client="ca-pub-1683150263600532" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
</head>
<body id="conn">
    <header>
         <div class="logo">
             <img src="../logo.png" alt="logo de New Inforatique 24">
            <h1>New Informatique <span>24</span></h1>
         </div>
     </header>

    <div id="form">
        <form method="post" enctype="multipart/form-data">
            <h3>Publier</h3>
            <p <?php if(isset($msg)) { ?> style=color:red; <?php } ?> >
                <i><?php if(isset($msg)){ echo $msg; } else { ?>Note : il n'est pas obligatoire de mettre une image si vous ne l'avez pas ! <?php } ?></i>
            </p>
            <input type="text" name="titre" placeholder="Titre" require>
            <textarea name="contenu" placeholder="Ecrire une publication ..." require></textarea>
            <p class="cap">Ajouter une image (Facultatif)</p>
            <input type="file" name="image_pub">
            
            <div class="btn">
                <a href="../">retour</a>
                <input type="submit" value="Publier" name="pub">   
            </div>      
        </form>
    </div>
</body>
</html>