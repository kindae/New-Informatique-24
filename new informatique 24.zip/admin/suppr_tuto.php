<?php
require_once "../php/config.php";
require_once "../php/connexion.php";

// Verification de l'envoie du formulaire
if (isset($_GET['id'])){

    $id_tuto = $_GET['id'];
    
    $suptuto = $bdd->prepare("UPDATE tutoriels SET actif_tuto = ? WHERE id_tuto = ?");
    $suptuto->execute(array("1", $id_tuto));
     
// Fermeture de la verification d'envoie
}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="alternate" href="../rss.php" type="application/rss+xml" title="tutoriels">
    <title>Administration - New informatique 24</title>
    <meta name="description" content="Apprendre l'inforatique en quelque jours avec New Inforatique. Nous avons les tutoriels et les cours, les cours sont en ligne et sureveiller 100% donc venez faire l'epreuve de la science.">
    <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="../apple-touch-icon.png">
    <link rel="mask-icon" href="../logo.png" color="#5bbad5">
    <link rel="manifest" href="../site.webmanifest">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/header.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="../css/form.css">
    <script data-ad-client="ca-pub-1683150263600532" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
</head>
<body id="conn">
    <header>
         <div class="logo">
             <img src="../logo.png" alt="logo de New Inforatique 24">
            <h1>New Informatique <span>24</span></h1>
         </div>
     </header>

    <div id="form">
        <form method="post" enctype="multipart/form-data">
            <h3>Tutoriel supprimer</h3>
            <p <?php if(isset($msg)) { ?> style=color:red; <?php } ?> >
                <i><?php if(isset($msg)){ echo $msg; } else { ?>Note : le tutoriel supprimer ! <?php } ?></i>
            </p>
            
            <div class="btn">
                <a href="../">retour</a>
            </div>      
        </form>
    </div>
</body>
</html>