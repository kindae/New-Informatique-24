<?php
require_once "../php/config.php";
require_once "../php/connexion.php";


$last_id = $bdd->LastInsertId();

if(isset($_POST['text']) AND !empty($_POST['text'])){

    $id_user = $_SESSION['id_ut'];
    $texte = $_POST['text'];

    $vrc = $bdd->query("SELECT * FROM citations");
    $vrc_row = $vrc->rowCount() + 1;
    $try = rand(1, $vrc);

    $dossier = "../images/citations/";

    if(isset($_FILES['image_pub']['tmp_name']) AND !empty($_FILES['image_pub']['tmp_name'])){
        $nom_img = "citation_000" . $vrc_row . "_" . $try . ".jpg";
        $fichier = $dossier . $nom_img;
        move_uploaded_file($_FILES['image_pub']['tmp_name'], $fichier);
        $image_pub = $nom_img;
    } else {
        $image_pub = "auto.jpg";
    }
    
    $insert = $bdd->prepare("INSERT INTO `citations`(`utilisateur`, `texte`, `image`) VALUES (?,?,?)");
    $insert->execute(array($id_user,$texte,$image_pub));

    if($insert){
        header("Location: citations.php");
    }
}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration - New informatique 24</title>
</head>
<body>
    <div id="body">
        <header>
            <h2><img src="img/logo.png"> Kinda-e - Administration</h2>
            <span>Citation</span>
        </header>

        <form method="post" enctype="multipart/form-data">
            <textarea name="text" placeholder="text citation"></textarea>
            <input type="file" name="image_pub">
            <input type="submit" name="btn">
        </form>
            
        <span class="copy">&copy; Kinda-e by geekcold</span>
    </div>

    <style type="text/css">
        *{
            padding: 0;
            margin: 0;
            font-family: arial;
        }
        body{
            background-color: #ccc;
        }
        header{
            background-color: #fff;

            padding: 10px 0;
        }
        header h2{
            display: flex;
            align-items: center;
            font-size: 20px;
            color: #0080ff;
            padding: 5px 10px;
        }
        header img{
            display: block;
            width: 32px;
            padding-right: 5px;
        }
        header span{
            display: block;
            padding: 5px 10px;
            color: #777;
            font-size: 16px;    
        }
        @media (max-width: 920px){
            header{
                padding: 5px 0;
            }
            header h2{
                font-size: 17px;
                padding: 5px 7px;
            }
            header img{
                width: 24px;
            }
            header span{
                display: block;
                padding: 5px 7px;
                font-size: 14px;
            }
        }
    </style>
</body>
</html>