<?php
require_once "../php/config.php";
require_once "../php/connexion.php";

// Verification de l'envoie du formulaire
if (isset($_POST['nom']) AND !empty($_POST['desc'])){

    $vrc = $bdd->query("SELECT * FROM cours");
    $vrc_row = $vrc->rowCount() + 1;

    $dossier = "../images/cours/";

    if(isset($_FILES['image_pub']['tmp_name']) AND !empty($_FILES['image_pub']['tmp_name'])){
        $nom_img = $vrc_row . ".jpg";
        $fichier = $dossier . $nom_img;
        move_uploaded_file($_FILES['image_pub']['tmp_name'], $fichier);
        $image_pub = $nom_img;
    } else {
        $image_pub = "auto.jpg";
    }

    $id_ut = $_SESSION['id_ut'];
    $nom = $_POST['nom'];
    $desc = $_POST['desc'];
    
    $inspub = $bdd->prepare("INSERT INTO cours (ut_cours, nom_cours, desc_cours, image_cours, actif_cours) VALUES (?, ?, ?, ?, ?)");
    $inspub->execute(array($id_ut, $nom, $desc, $image_pub, "0"));

    header("Location: ../cours.php");
     
// Fermeture de la verification d'envoie
}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="alternate" href="../rss.php" type="application/rss+xml" title="tutoriels">
    <title>Administration - New informatique 24</title>
    <meta name="description" content="Apprendre l'inforatique en quelque jours avec New Inforatique. Nous avons les tutoriels et les cours, les cours sont en ligne et sureveiller 100% donc venez faire l'epreuve de la science.">
    <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="../apple-touch-icon.png">
    <link rel="mask-icon" href="../logo.png" color="#5bbad5">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/header.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="../css/form.css">
</head>
<body id="conn">
    <header>
         <div class="logo">
             <img src="../logo.png" alt="logo de New Inforatique 24">
            <h1>New Informatique <span>24</span></h1>
         </div>
     </header>

    <div id="form">
        <form method="post" enctype="multipart/form-data">
            <h3>Publier</h3>
            <p <?php if(isset($msg)) { ?> style=color:red; <?php } ?> >
                <i><?php if(isset($msg)){ echo $msg; } else { ?>Note : il n'est pas obligatoire de mettre une image si vous ne l'avez pas ! <?php } ?></i>
            </p>
            <input type="text" name="nom" placeholder="Nom du cours">
            <textarea name="desc" placeholder="Ecrire une petite description ..." require></textarea>
            <p class="cap">Ajouter une image (Facultatif)</p>
            <input type="file" name="image_pub" require>
            
            <div class="btn">
                <a href="../">retour</a>
                <input type="submit" value="Ajouter" name="pub">   
            </div>      
        </form>
    </div>
</body>
</html>