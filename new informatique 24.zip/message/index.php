<?php
require_once("../php/config.php");
require_once("../php/connexion.php");

$utd = $bdd->prepare("SELECT * FROM messages WHERE ut = ? OR utd = ? ORDER BY date DESC LIMIT 0,25");
$utd->execute(array($_SESSION['id_ut'], $_SESSION['id_ut']));
$utd_r = $utd->rowCount();

$nu = $bdd->query("SELECT * FROM utilisateurs ORDER BY date_ut DESC LIMIT 0,10");

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="apropos, Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title>messages privés</title>
    <meta property="og:title" content="message privé" />

    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/apercu.css">

    <?php include("inc/head.php") ?>
</head>
<body>
    <header>
        <a href="../" class="title">
            <img src="images/logo.png" alt="logo new informatique 24">
            <span>New Informatique 24</span>
        </a>

        <a href="../" class="btn">Retour</a>
    </header>

    <div class="aff_msg">
        <form action="recherche.php" method="get">
            <input type="search" name="rc" placeholder="Recherche">
            <input type="submit" value="Recherche">
        </form>

        <div class="list">
            <a href="recherche.php">Nouveau message</a>
            <a href="personnes.php?infos=1">Mes contacts</a>
        </div>
        
        <div class="list">
            <h1>Messages</h1>

            <?php while($utd_a = $utd->fetch()){ 
                
                if($utd_a['ut'] == $_SESSION['id_ut']){
                    $utd_id = $utd_a['utd'];
                } else {
                    $utd_id = $utd_a['ut'];
                }

                $utd_name_s = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
                $utd_name_s->execute(array($utd_id));
                $utd_name = $utd_name_s->fetch()['nom'];

                $vr_msg = $bdd->prepare("SELECT * FROM message WHERE vu = ? AND (ut = ? AND utd = ? OR utd = ? AND ut = ?)");
                $vr_msg->execute(array($_SESSION['id_ut'], $_SESSION['id_ut'], $utd_id, $_SESSION['id_ut'], $utd_id));
                $vr_msg_r = $vr_msg->rowCount();
            ?>
            
            <style>
                span.r{
                    background: red;
                    font-size: 14px;
                    color: #fff;
                    padding: 4px;
                }
            </style>

            <a href="message.php?infos=<?= $utd_id ?>#vu"><?= $utd_name ?> <?php if($vr_msg_r > 0){ ?><span class="r"><?= $vr_msg_r ?></span><?php } ?></a>

            <?php } ?>

            <?php if($utd_r == 0){ ?>
            <a>Aucun message trouvé</a>
            <?php } ?>

        </div> 
        
        <div class="list">
            <h1>Nouveau utilisateur</h1>

            <?php while($nu_a = $nu->fetch()){ ?>
            <a href="message.php?infos=<?= $nu_a['id_ut'] ?>#vu"><?= $nu_a['user_ut'] ?></a>
            <?php } ?>

        </div> 

    </div>

    <footer>
        <p>Messages - New Informatique 24</p>
    </footer>
</body>
</html>