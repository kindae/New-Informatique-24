<?php
require_once("../php/config.php");
require_once("../php/connexion.php");

if(isset($_GET['infos']) AND !empty($_GET['infos'])){

    $utd = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
    $utd->execute(array($_GET['infos']));
    $utd_r = $utd->rowCount();

    if($utd_r == 1){

        $utd_f = $utd->fetch();
        $nom = $utd_f['nom'];
        $photo = $utd_f['photo'];

        $fix_vu_msg = $bdd->prepare("UPDATE message SET vu = ? WHERE vu = ? AND (ut = ? AND utd = ? OR utd = ? AND ut = ?)");
        $fix_vu_msg->execute(array(0, $_SESSION['id_ut'], $_SESSION['id_ut'], $_GET['infos'], $_SESSION['id_ut'], $_GET['infos']));
        

        if(isset($_POST['envoi']) AND !empty($_POST['texte'])){

            $texte = htmlspecialchars($_POST['texte']);
            $envoi_m = $bdd->prepare("INSERT INTO `message`(`ut`, `utd`, `message`, `type`, `vu`) VALUES (?, ?, ?, ?, ?)");
            $envoi_m->execute(array($_SESSION['id_ut'], $_GET['infos'], $texte, "1", $_GET['infos']));

            $vr_enreg = $bdd->prepare("SELECT * FROM messages WHERE ut = ? AND utd = ? OR ut = ? AND utd = ?");
            $vr_enreg->execute(array($_SESSION['id_ut'], $_GET['infos'], $_GET['infos'], $_SESSION['id_ut']));
            $vr_enreg_r = $vr_enreg->rowCount();

            if($vr_enreg_r == 0){

                $enreg_m = $bdd->prepare("INSERT INTO messages(`ut`, `utd`, `actif`) VALUES (?, ?, ?)");
                $enreg_m->execute(array($_SESSION['id_ut'], $_GET['infos'], 0));

            } else {

                $ms_f = $vr_enreg->fetch();
                $id_ms = $ms_f['id'];
                $date_ms = date('d-m-Y');

                $enreg_m = $bdd->prepare("UPDATE messages SET date = NOW() WHERE id = ?");
                $enreg_m->execute(array($id_ms));
            }
        }

        $messages = $bdd->prepare("SELECT * FROM message WHERE ut = ? AND utd = ? OR ut = ? AND utd = ? ORDER BY date ASC LIMIT 0,25");
        $messages->execute(array($_SESSION['id_ut'], $_GET['infos'], $_GET['infos'], $_SESSION['id_ut']));
        $messages_r = $messages->rowCount();

    } else {
        header("Location: connexion.php");
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="apropos, Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title>message privé</title>
    <meta property="og:title" content="message privé" />

    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/msg.css">

    <?php include("inc/head.php") ?>
    
</head>
<body>
    <header>
        <a class="btn" href="index.php">◄</a>  
        <a class="title"><?= $nom ?></a>
        <img src="../images/profil/<?= $photo ?>">
    </header>
    <div>
        <a class="plus">mode privé</a>

        <?php while($message = $messages->fetch()){ 
            
        if($message['ut'] == $_SESSION['id_ut']){ ?>

        <section class="moi">
            <p>
            <?= nl2br($message['message']) ?>
                <span class="nom"><?= date("H:i", strtotime($message['date']))?><span>
            </p>         
        </section>

        <?php } else { ?>

        <section>
            <a><img src="../images/profil/<?= $photo ?>"></a>

            <p>
                <?= nl2br($message['message']) ?>
                <span class="nom"><?= date("H:i", strtotime($message['date']))?></span>
            </p>         
        </section>

        <?php }} ?>   
        
        <a id="vu" name="vu"></a>

        <?php if($messages_r == 0){ ?>

        <br><br><br>
        <p align="center">Vous n'avez aucun message avec cette contact !</p>

        <?php } ?>
    </div>
    <footer>
        <form method="post">
            <textarea name="texte"></textarea>
            <input type="submit" value="Envoyer" name="envoi">
        </form>
    </footer>
</body>
</html>