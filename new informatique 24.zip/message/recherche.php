<?php
require_once("../php/config.php");
require_once("../php/connexion.php");

$nu = $bdd->query("SELECT * FROM informations ORDER BY nom ASC LIMIT 0,100");
$nu_r = $nu->rowCount();

if(isset($_GET['rc']) AND !empty($_GET['rc'])){

    $rc = $_GET['rc'];

    $nu = $bdd->prepare("SELECT * FROM informations WHERE nom LIKE ? ORDER BY nom ASC LIMIT 0,100");
    $nu->execute(array("%$rc%"));
    $nu_r = $nu->rowCount();

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="apropos, Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title>Recherche - messages</title>
    <meta property="og:title" content="Personnes" />

    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/apercu.css">

    <?php include("inc/head.php") ?>
</head>
<body>
    <header>
        <a href="../index.php" class="title">
            <img src="images/logo.png" alt="logo new informatique 24">
            <span>New Informatique 24</span>
        </a>

        <a href="index.php" class="btn">Retour</a>
    </header>

    <div class="aff_msg">
        <form action="recherche.php" method="get">
            <input type="search" name="rc" placeholder="Recherche" value="<?php if(isset($_GET['rc'])){ echo $_GET['rc']; } ?>">
            <input type="submit" value="Recherche">
        </form>

        <div class="list">
            <h1>Personnes (<?= $nu_r ?>)</h1>

            <?php while($nu_a = $nu->fetch()){ ?>
            <a href="message.php?infos=<?= $nu_a['id_ut'] ?>#vu"><?= $nu_a['nom'] ?></a>
            <?php } ?>

            <?php if($nu_r == 0){ ?>
            <br><br><br>
            <a>Aucun utilisateur trouvé</a>
            <?php } ?>
        </div>

        <br><br><br><br><br>
        <p align="center">les messages sont securisé !</p>     
        <br><br><br><br><br>
    </div>

    <footer>
        <p>Messages - New Informatique 24</p>
    </footer>
</body>
</html>