
<!-- meta details -->
<meta name="description" content="message privé">
<meta property="og:description" content="message privé" />

<!-- links -->
<link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="../apple-touch-icon.png">

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-JBKZDMLQWB"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-JBKZDMLQWB');
</script>

<!-- Google Adsense -->
<script data-ad-client="ca-pub-1683150263600532" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>