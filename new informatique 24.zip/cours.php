<?php
require_once "php/config.php";

$vrcours = $bdd->prepare("SELECT * FROM cours WHERE actif_cours = ?");
$vrcours->execute(array("0"));
$vrcours_row = $vrcours->rowCount();

if(isset($_GET['rc']) AND !empty($_GET['rc'])){

    $rc_infos = $_GET['rc'];

    $selcours = $bdd->prepare("SELECT * FROM cours WHERE actif_cours = ? AND nom_cours LIKE ? ORDER BY date_cours DESC LIMIT 0,25");
    $selcours->execute(array("0", "%$rc_infos%"));
    $selcours_row = $selcours->rowCount();

} elseif (isset($_GET['page']) AND !empty($_GET['page'])){

    $pageseld = ($_GET['page'] - 1)*10;
    $parpages = 10;
    $psel = $pageseld . "," . $parpages;

    $selcours = $bdd->prepare("SELECT * FROM cours WHERE actif_cours = ? ORDER BY date_cours DESC LIMIT " . $psel);
    $selcours->execute(array("0"));
    $selcours_row = $selcours->rowCount();

} else {

    $selcours = $bdd->prepare("SELECT * FROM cours WHERE actif_cours = ? ORDER BY date_cours DESC LIMIT 0,10");
    $selcours->execute(array("0"));
    $selcours_row = $selcours->rowCount();

}

$og_titre = "Cours";
$og_desc = "Apprendre l'informatique en quelque jours avec New Informatique. Nous avons des tutoriels et des cours, les cours sont donnés en ligne et sureveiller à 100%...";
$og_image = "https://newinformatique24.com/logo.jpg";


?>

<!DOCTYPE html>
<html>
<head>

    <?php require "inc/head.php" ?>

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/cours.css">
</head>
<body>
     
    <?php include "inc/header.php" ?>
     
    <div id="c">

        <?php include "inc/menu.php" ?>

        <div id="pr" class="cours">

        <?php if (isset($_SESSION['id_ut'])) { 
            
            $vrnivcours = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
            $vrnivcours->execute(array($_SESSION['id_ut']));
            $nivutcours = $vrnivcours->fetch()['niveau'];

            if ($nivutcours > 0 AND $nivutcours < 9) { ?>

                <div class="editeur">
                <a href="admin/add_cours.php">
                    <img src="images/items/add.jpg" alt="image d'ajoute tutoriel">
                    <span>Ajouter un Cours</span>
                </a>
                </div>

        <?php } else { ?>

                <div class="editeur">
                    <a>
                        <p>vous n'etes pas autoriser a publier des cours</p>
                    </a>
                </div>

        <?php }
        } else { ?>

            <div class="editeur">
                <a>
                    <p>Vous etes dans l'option des cours</p>
                </a>
            </div>
            
        <?php }

        while($cours = $selcours->fetch()) {
        
        ?>

            <a href="chapitre.php?cours=<?= $cours['id_cours'] ?>" title="nom_cours" class="cours_aff">
                <img src="images/cours/<?= $cours['image_cours']; ?>" alt="<?= $cours['nom_cours']; ?>">
                <div>
                    <h3><?= $cours['nom_cours']; ?></h3>
                    <p><?= substr( htmlspecialchars($cours['desc_cours']), 0, 300) ?> ...</p>
                    <p class="mob"><?= substr( htmlspecialchars($cours['desc_cours']), 0, 50) ?> ...</p>
                    <p class="date"><?= date("d F Y, H:i",strtotime($cours['date_cours'])) ?></p>
                </div>
            </a>

        <?php } 
          
        if($selcours_row == 0) { ?>

            <h2 style="color:white;">Aucun cours ajouter !</h2>
        
        <?php } ?>
        
        <?php if(!isset($rc_infos)){ ?>

            <div class="pagination">

            <?php $pagescours = $vrcours_row / 10;
            
            if(isset($_GET['page']) AND !empty($_GET['page'])){

                if ($pagescours > $_GET['page']) { $pap = $_GET['page'] - 1; $pas = $_GET['page'] + 1;?>

                    <a href="cours.php?page=<?= $pap ?>">Precedente</a>
                    <a href="cours.php?page=<?= $pas ?>">Suivante</a>

                <?php } else { $pap = $_GET['page'] - 1; ?>

                    <a href="cours.php?page=<?= $pap ?>">Precedente</a>
                    <a class="inactive">Suivante</a>

                <?php }

            } else {

                if ($vrcours_row > 10) { ?>

                    <a class="inactive">Precedente</a>
                    <a href="cours.php?page=2">Suivante</a>

            <?php } } ?>

            </div>

        <?php } ?>

        </div>
    </div>

    <?php include "inc/secondaire.php" ?>

    <?php include "inc/footer.php" ?>

</body>
</html>