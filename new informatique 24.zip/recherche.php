<?php
require_once "php/config.php";

if(isset($_GET['rc']) AND !empty($_GET['rc'])){

    $rc = $_GET['rc'];

    //$vrcours = $bdd->prepare("SELECT * FROM cours WHERE actif_cours = ? AND nom_cours LIKE ?");
    //$vrcours->execute(array("0", "%$rc%"));
    //$nbrcours = $vrcours->rowCount();
    //$liencours = "cours.php?rc=" . $rc;

    $vrtutos = $bdd->prepare("SELECT * FROM tutoriels WHERE actif_tuto = ? AND titre_tuto LIKE ?");
    $vrtutos->execute(array("0", "%$rc%"));
    $nbrtuto = $vrtutos->rowCount();
    $lientuto = "tutoriels.php?rc=" . $rc;

    $selmot = $bdd->prepare("SELECT * FROM dico WHERE actif_mot = ? AND mot LIKE ?");
    $selmot->execute(array("0", "%$rc%"));
    $nbrmots = $selmot->rowCount();
    $lienmots = "dico.php?rc=" . $rc;

    $annonces = $bdd->prepare("SELECT * FROM annonces WHERE titre LIKE ?");
    $annonces->execute(array("%$rc%"));
    $nbrannonces = $annonces->rowCount();
    $lienannonces = "annonces.php?rc=" . $rc;

} else {

    $vrcours = $bdd->prepare("SELECT * FROM cours WHERE actif_cours = ?");
    $vrcours->execute(array("0"));
    $nbrcours = $vrcours->rowCount();
    $liencours = "cours.php";

    $vrtutos = $bdd->prepare("SELECT * FROM tutoriels WHERE actif_tuto = ?");
    $vrtutos->execute(array("0"));
    $nbrtuto = $vrtutos->rowCount();
    $lientuto = "tutoriels.php";

    $selmot = $bdd->prepare("SELECT * FROM dico WHERE actif_mot = ?");
    $selmot->execute(array("0"));
    $nbrmots = $selmot->rowCount();
    $lienmots = "dico.php";

    $annonces = $bdd->query("SELECT * FROM annonces");
    $nbrannonces = $annonces->rowCount();
    $lienannonces = "annonces.php";

}

$og_titre = "New Informatique 24 - Recherche";
$og_desc = "Vous trouverez des ressources sur : \n\r \n\r - Des cours sur le domaine informatique \n\r - Des tutoriels présentant une tâche précise et initiant sur la façon de l'accomplir \n\r - Des explications sur differents mots du jargon informatique \n\r - et tant d'autres annonces interssantes sur le monde info...";
$og_image = "https://newinformatique24.com/logo.jpg";

?>

<!DOCTYPE html>
<html>
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti, cours, tutoriel">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png">

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/cours.css">

    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body>
     
    <?php include "inc/header.php" ?>
     
    <div id="c">

        <?php include "inc/menu.php" ?>

        <div id="pr" class="cours">

            <a class="cours_aff">    
                <div>
                    <h3>Recherche</h3>
                    <p>Le recherche sur cette page cible les cours, les tutoriels, les mots et les annonces publier déjà dans ce siteweb !</p>
                    <p class="mob">Le recherche sur cette page cible les cours, les tutoriels, les mots et les annonces publier déjà dans ce siteweb !</p>
                    <p class="date">Annonce</p>
                </div>
            </a>
            <br><br>

            <a href="" title="cours" class="cours_aff"> 
                <div>
                    <h3>Cours (0)</h3>
                    <p class="date">il y a 0 cours Trouvées</p>
                </div>
            </a>
            <a href="<?= $lientuto ?>" title="tutoriels" class="cours_aff"> 
                <div>
                    <h3>Tutoriels (<?= $nbrtuto ?>)</h3>
                    <p class="date">il y a <?= $nbrtuto ?> Tutoriels Trouvées</p>
                </div>
            </a>
            <a href="<?= $lienmots ?>" title="mots" class="cours_aff"> 
                <div>
                    <h3>Mots (<?= $nbrmots ?>)</h3>
                    <p class="date">il y a <?= $nbrmots ?> Mots Trouvées</p>
                </div>
            </a>
            <a href="<?= $lienannonces ?>" title="annonces" class="cours_aff"> 
                <div>
                    <h3>Annonces (<?= $nbrannonces ?>)</h3>
                    <p class="date">il y a <?= $nbrannonces ?> annonces Trouvées</p>
                </div>
            </a>
            
            <br><br>
        </div>    
    </div>

    <?php include "inc/secondaire.php" ?>

    <?php include "inc/footer.php" ?>

</body>
</html>