<?php
require_once "php/config.php";

// Verification de l'envoie du formulaire
if (isset($_POST['connexion'])){

    // Verfification d'envoie de chaque champs du formulaire
    if (!empty($_POST['email_co']) AND !empty($_POST['mdp_co'])){

        // Attribution des valeurs aux variables
        $email_co = htmlspecialchars(strtolower($_POST['email_co']));
        $mdp_co = sha1($_POST['mdp_co']);

        // Verificationsur la table apropos d'utilisateur
        $vr_us_tbl = $bdd->prepare("SELECT * FROM utilisateurs WHERE user_ut = ? AND password_ut = ?");
        $vr_us_tbl->execute(array($email_co, $mdp_co));
        $vr_us_tbl_row = $vr_us_tbl->rowCount();
        if ($vr_us_tbl_row == 1){

            // Partage d'accees
            $ut_co = $vr_us_tbl->fetch();
            $_SESSION['id_ut'] = $ut_co['id_ut'];
            $_SESSION['email_ut'] = $ut_co['user_ut'];
            $_SESSION['mdp_ut'] = $ut_co['password_ut'];

            header("Location: profil.php?id_utilisateur=" . $_SESSION['id_ut']);

        // Fin verification de l'utilisateur sur la table
        } else {
           $msg = "Vos informations sont incorrect !";
        }
        
    // Fermeture de la verification de non vide de chaque champs
    } else {
        $msg = "Veuillez remplir les champs completement !";
    }

// Fermeture de la verification d'envoie
}

$og_titre = "New Informatique 24 - Connexion";
$og_desc = "Formulaire de connexion : veuillez remplir l'email et le mot de pass...";
$og_image = "https://newinformatique24.com/logo.jpg";


?>

<!DOCTYPE html>
<html>
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti, cours, tutoriel">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png">

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/form.css">

    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body id="conn">
    <header>
         <div class="logo">
             <img src="logo.png" alt="logo de New Inforatique 24">
            <h1>New Informatique <span>24</span></h1>
         </div>
     </header>

    <div id="form">
        <form method="post">
            <h3>Formulaire de connexion</h3>
            <p <?php if(isset($msg)) { ?> style=color:red; <?php } ?> >
                <i><?php if(isset($msg)){ echo $msg; } else { ?>Note : il est obligatoire de tout remplir sur le formulaire ici present ! <?php } ?></i>
            </p>
            <p class="cap">Adresse messagerie</p>
            <input type="email" name="email_co" placeholder="Votre Adresse mail" required>
            <p class="cap">Mot de passe</p>
            <input type="password" name="mdp_co" placeholder="Mot de passe" required>
            <div class="btn">
                <a href="inscription.php">Je veux m'inscrire</a>
                <input type="submit" value="Connexion" name="connexion">   
            </div>      
        </form>
    </div>
</body>
</html>