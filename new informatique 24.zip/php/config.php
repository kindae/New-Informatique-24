<?php
session_start();

$bdd = new PDO("mysql:host=localhost;dbname=newinformatique24bdd;charset=utf8", "root", "")

?>     