<?php

if (isset($_SESSION['id_ut'],$_SESSION['email_ut'])) {
    
    $id_ut = $_SESSION['id_ut'];
    $email_ut = $_SESSION['email_ut'];

    $utilisateur_ut = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
    $utilisateur_ut->execute(array($_SESSION['id_ut']));

    $utilisateur_ut_row = $utilisateur_ut->rowCount();

    if ($utilisateur_ut_row == 1) {
        
        $utt_ut = $utilisateur_ut->fetch();
        
        $nom_ut = $utt_ut['nom'];
        $tel_ut = $utt_ut['telephone'];
        $sexe_ut = $utt_ut['sexe'];
        $pays_ut = $utt_ut['pays'];
        $adresse_ut = $utt_ut['adresse'];
        $photo_ut = $utt_ut['photo'];
        $niveau_ut = $utt_ut['niveau'];

    } else {

        $nom_ut = "inconnu";
        $tel_ut = "inconnu";
        $sexe_ut = "inconnu";
        $pays_ut = "inconnu";
        $adresse_ut = "inconnu";
        $photo_ut = "auto.jpg";
        $niveau_ut = "0";

    }
} else {

    header("Location: connexion.php");

}