<?php
require_once "php/config.php";

if(isset($_POST['envoie'])){
    if (!empty($_POST['nomc']) AND !empty($_POST['mailc']) AND !empty($_POST['msgc'])){
        
        ini_set('display_errors', 1);
        error_reporting( E_ALL );

        
        $destinataires = $_POST['mailc'];
        $sujet = "Message du site de la part de " . $_POST['nomc'];

        // en-têtes expéditeur
        $entetes= "From : \"New Informatique 24\"<notification@newinformatique24.com>\n";

        // en-têtes adresse de retour
        $entetes .= "Reply-to : henryfiti1@gmail.com\n";

        // personnes en copie
        $entetes .= "Cc : henryfiti1@gmail.com\n";
        $entetes .= "Bcc : henryfiti2@gmail.com\n";

        // priorité urgente
        $entetes .= "X-Priority : 1\n";

        // message
        $message =
        "
            New Informatique 24 Notification en Francais : \r\n \r\n
        "
        .   htmlspecialchars($_POST['msgc']) .
        "
            \r\n \r\n
            Le message a ete reçu avec succès par la gestion de messagerie et apres verification vous serez relancer par Monsieur Henry FITI et il vous relancerai avec son adresse mail : Henryfiti1@gmail.com !

            \r\n \r\n
            Envoyez par : " . $_POST['mailc'] . " \r\n
            Date de reception : " . date('d-m-Y') . " \r\n
            Site : New Informatique 24 \r\n
            Adresse : newinformatique24.com \r\n
        ";
        
        if (mail($destinataires, $sujet, $message, $entetes)){
            $reussi = "Votre message a ete envoyer avec succès !";

            ?>

            <div style="background:#00ff00;padding:30px;border:2px solid #ccffcc;font-size:17px;">
                <p> <?= $reussi; ?></p>
            </div>

            <?php
        }    
    }
}

$og_titre = "Contactez-nous";
$og_desc = "informations de contact, Republique Democratique du Congo sur l'Avenue : Bateke, 6D à la commune de Matete / Mont-Amba dans la Ville de Kinshasa, Telephone : +243 (0) 82 93 47 920 | +243 (0) 97 47 42 713, Email : henryfiti1@gmail.com, Service client : contactt@newinformatique24.com, Facebook : New Informatique 2...";
$og_image = "https://newinformatique24.com/logo.jpg";


?>

<!DOCTYPE html>
<html>
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="contact, Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png">

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/styles_sc.css">

    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body>
    <header>
        <a href="accueil" class="title">
            <img src="logo.png" alt="logo new informatique 24">
            <span>New Informatique 24</span>
        </a>

        <a href="accueil" class="btn">Retour</a>
    </header>
    <div class="aff_text">
        <div class="titre">
            <h1>Contactez-nous</h1>
            <p>
                Ce qui suit represente des données et informations fournis par New Informatique 24 !
            </p>
        </div>
        
        <form method="post">

            <div class="long">
                <p>Nom Complet</p>
                <input type="text" name="nomc" placeholder="Votre Nom" required>
            </div>
            <div class="long">
                <p>Adresse Mail</p>
                <input type="email" name="mailc" placeholder="Votre adresse E-mail" required>
            </div>
            <div class="long">
                <p>Messages</p>
                <textarea name="msgc" placeholder="Contenu du message" required></textarea>
            </div>
            
            <p>
                En soumettant ce formulaire, j'accepte que les informations saisies soient exploitées dans le cadre de la demande de contact et relation commerciale qui peut en decouler. je suis d'accord avec la <a href="">politique de confidentialité</a>
            </p>

            <br>
            <input type="submit" value="Envoyer" name="envoie">
        </form>
        <div class="list">   
            <h2>informations de contact</h2>
            <p>
                Republique Democratique du Congo
                <br><br>
                Avenue : Bateke, 6D
                <br>
                Matete / Mont-Amba
                <br>
                Ville : Kinshasa
                <br><br>

                Telephone : +243 (0) 82 93 47 920 | +243 (0) 97 47 42 713
                <br>
                Email : henryfiti1@gmail.com
                <br>
                Service client : contactt@newinformatique24.com
                <br>
                Facebook : New Informatique 24
                <br>
                Telegram : New Informatique 24
                <br>
                Instagram : @newinformatique24
                <br>
            </p>
        </div>
        <nav>
            <a href="accueil">Accueil</a>
            <a href="apropos">A propos de nous</a>
            <a href="contact">Contactez-nous</a>
            <a href="confidentialite" target="_blank" rel="noopener noreferrer">Politique de confidentialité</a>
            <a href="non_responsabilite.php" target="_blank" rel="noopener noreferrer">Clause de non-resposabilité</a>
        </nav>
    </div>

    <footer>
        <p>Copyright &copy; - New Informatique 24</p>
    </footer>
</body>
</html>