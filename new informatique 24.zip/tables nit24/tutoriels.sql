-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 29 juil. 2021 à 14:30
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `newinformatique24bdd`
--

-- --------------------------------------------------------

--
-- Structure de la table `tutoriels`
--

DROP TABLE IF EXISTS `tutoriels`;
CREATE TABLE IF NOT EXISTS `tutoriels` (
  `id_tuto` int(11) NOT NULL AUTO_INCREMENT,
  `titre_tuto` varchar(255) NOT NULL,
  `date_cr_tuto` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_ed_tuto` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_ut` varchar(255) NOT NULL,
  `actif_tuto` varchar(255) NOT NULL,
  `lien_ext_tuto` varchar(255) NOT NULL,
  `image_tuto` varchar(255) NOT NULL,
  `contenu_tuto` text NOT NULL,
  PRIMARY KEY (`id_tuto`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
