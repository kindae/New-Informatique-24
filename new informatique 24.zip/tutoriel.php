<?php
require_once "php/config.php";

if (isset($_GET['tuto']) AND !empty($_GET['tuto'])){

    $id_tuto = $_GET['tuto'];

    $seltuto = $bdd->prepare("SELECT * FROM tutoriels WHERE id_tuto = ?");
    $seltuto->execute(array($id_tuto));
    $seltuto_row = $seltuto->rowCount();

    if ($seltuto_row == 1){

        $tuto_view = $seltuto->fetch();
        
        $titre_tuto = $tuto_view['titre_tuto'];
        $date_cr_tuto = $tuto_view['date_cr_tuto'];
        $date_ed_tuto = $tuto_view['date_ed_tuto'];
        $image_tuto = $tuto_view['image_tuto'];
        $lien_tuto = $tuto_view['lien_ext_tuto'];
        $contenu_tuto = $tuto_view['contenu_tuto'];

        $id_nom_tuto = $tuto_view['id_ut'];
        $sel_nom_tuto = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
        $sel_nom_tuto->execute(array($id_nom_tuto));
    
        $nom_tuto_row = $sel_nom_tuto->rowCount();
    
        if ($nom_tuto_row == 1) {
            
            $nom_tuto_ft = $sel_nom_tuto->fetch();
            $nom_tuto = $nom_tuto_ft['nom'];

        } else {

            $nom_tuto = "inconnu";
        } 

    } else {

        header("Location: tutoriels.php");

    }

} else {

    header("Location: tutoriels.php");

}

$og_titre = $titre_tuto;
$og_desc = substr(htmlspecialchars($contenu_tuto), 0, 300) . "...";
$og_image = "https://newinformatique24.com/images/tuto/" . $image_tuto;

?>

<!DOCTYPE html>
<html>
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti, cours, tutoriel">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png">

    <meta property="og:url" content="http://newinformatique24.com/tutoriel.php?tuto=<?= $id_tuto ?>" />

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/apercu.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/tuto.css">
    
    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body>
     
    <?php include "inc/header.php" ?>
     
    <div id="c">

        <?php include "inc/menu.php" ?>

        <div id="pr">
            <div class="apercu_tuto"> 
                <p class="date">
                    <span>Posté Par: <?= $nom_tuto ?></span>
                    <span>Creer: <?= date("d F Y, H:i",strtotime($date_cr_tuto))?></span>
                    <span>Modifier: <?= date("d F Y, H:i",strtotime($date_ed_tuto))?></span>  
                </p>
                <p>Pour en savoir plus lire :</p>
                
                <?php if($lien_tuto == "auto"){ ?>

                <img class="youtube" src="images/tuto/<?= $image_tuto ?>" alt="<?= $titre_tuto ?>">

                <?php } else { ?>

                <iframe class="youtube" src="<?= $lien_tuto ?>" title="<?= $titre_tuto ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                
                <?php } ?>
                <br><br>
                <h2><?= $titre_tuto ?></h2>

                <style>
                    p.contenu{
                        padding: 25px 10px;
                    }
                    p.contenu img{
                        display: block;
                        width: 300px;
                        padding: 20px;
                    }
                    @media (max-width: 920px){
                        p.contenu{
                            padding: 25px 10px;
                        }
                        p.contenu img{
                            display: block;
                            width: 100%;
                            padding: 20px 0;
                            margin: 0 auto;
                        }
                    }
                </style>
                <p class="contenu"><?= nl2br($contenu_tuto) ?></p>

                <?php if (isset($_SESSION['id_ut'])) { 
            
                $vrnivt = $bdd->prepare("SELECT * FROM informations WHERE id_ut = ?");
                $vrnivt->execute(array($_SESSION['id_ut']));
                $nivt = $vrnivt->fetch()['niveau'];

                if ($nivt == 1 ) { ?>

                <a href="admin/suppr_tuto.php?id=<?= $id_tuto ?>">Supprimer</a>

                <?php }}?>
                
                <?php include "inc/commentaire.php" ?>
            </div>
        </div>
    </div>

    <?php include "inc/secondaire.php" ?>

    <?php include "inc/footer.php" ?>

</body>
</html>