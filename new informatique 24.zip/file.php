<?php
require_once "php/config.php";

$vrtutos = $bdd->prepare("SELECT * FROM tutoriels WHERE actif_tuto = ?");
$vrtutos->execute(array("0"));
$nbrtuto = $vrtutos->rowCount();
$lientuto = "tutoriels.php";

$selmot = $bdd->prepare("SELECT * FROM dico WHERE actif_mot = ?");
$selmot->execute(array("0"));
$nbrmots = $selmot->rowCount();
$lienmots = "dico.php";

$annonces = $bdd->query("SELECT * FROM annonces");
$nbrannonces = $annonces->rowCount();
$lienannonces = "annonces.php";

$a = 1;

echo nl2br("Liste des articles \n\r \n\r");

sort(array(while($vrtuto = $vrtutos->fetch() OR $selm = $selmot->fetch() OR $annonce = $annonces->fetch()){
    
    
    
    if(isset($vrtuto['titre_tuto'])){

        echo nl2br($a . ". " . $vrtuto['titre_tuto'] . " (tutoriel) \r\n \r\n");   

    } elseif(isset($selm['mot'])){

        echo nl2br($a . ". " . $selm['mot'] . " (dico-wiki)\r\n \r\n");   

    } elseif(isset($annonce['titre'])){

        echo nl2br($a . ". " . $annonce['titre'] . " (annonce)\r\n \r\n");

    }

    $a = $a + 1;

}));

?>