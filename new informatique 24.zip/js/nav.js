function openNav() {
    document.getElementById("menunav")
    .style.display="block";

    document.getElementById("openmenu")
    .style.top="-100%";

    document.getElementById("closemenu")
    .style.top="0%";
}
   
function closeNav() {
    document.getElementById("menunav")
    .style.display = "none";

    document.getElementById("openmenu")
    .style.top="0%";

    document.getElementById("closemenu")
    .style.top="-100%";
}

