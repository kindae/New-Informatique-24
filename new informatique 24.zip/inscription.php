<?php
require_once "php/config.php";

// Verification de l'envoie du formulaire
if (isset($_POST['inscrit'])){

    // Verfification d'envoie de chaque champs du formulaire
    if (!empty($_POST['nom_ut']) AND !empty($_POST['genre_ut']) AND !empty($_POST['pays_ut']) AND !empty($_POST['adr_ut']) AND !empty($_POST['email_ut']) AND !empty($_POST['tel_ut']) AND !empty($_POST['mdp_ut']) AND !empty($_POST['mdp2_ut'])){

        // Attribution des valeurs aux variables
        $nom_ut = htmlspecialchars($_POST['nom_ut']);
        $genre_ut = htmlspecialchars($_POST['genre_ut']);
        $pays_ut = htmlspecialchars($_POST['pays_ut']);
        $adr_ut = htmlspecialchars($_POST['adr_ut']);
        $email_ut = htmlspecialchars(strtolower($_POST['email_ut']));
        $tel_ut = htmlspecialchars($_POST['tel_ut']);
        $mdp_ut = sha1($_POST['mdp_ut']);
        $mdp2_ut = sha1($_POST['mdp2_ut']);
        $photo_ut = "auto.jpg";
        
        $vr_niv = $bdd->query("SELECT * FROM utilisateurs");
        $vr_niv_row = $vr_niv->rowCount();
        
        if ($vr_niv_row == 0){
            $niv_ut = 1;
        } else {
            $niv_ut = 0;
        }     

        // Verificationsur la table apropos d'utilisateur
        $vr_us_tbl = $bdd->prepare("SELECT * FROM utilisateurs WHERE user_ut = ?");
        $vr_us_tbl->execute(array($email_ut));
        $vr_us_tbl_row = $vr_us_tbl->rowCount();
        if ($vr_us_tbl_row == 0){

            // Verification des 2 mot de passe
            if($mdp_ut == $mdp2_ut){
                $ins_us_tbl = $bdd->prepare("INSERT INTO utilisateurs (user_ut, password_ut) VALUES (?,?)");
                $ins_us_tbl->execute(array($email_ut, $mdp_ut));

                if(isset($ins_us_tbl)){
                    
                    $vr_us_tbl2 = $bdd->prepare("SELECT * FROM utilisateurs WHERE user_ut = ? AND password_ut = ?");
                    $vr_us_tbl2->execute(array($email_ut, $mdp_ut));
                    $vr_us_tbl2_row = $vr_us_tbl2->rowCount();
                    if ($vr_us_tbl2_row == 1){
                        
                        $ut_co = $vr_us_tbl2->fetch();

                        // enregistrement d'informations sur la table 2
                        $ins_us_tbl = $bdd->prepare("INSERT INTO informations (id_ut, nom, telephone, sexe, pays, adresse, photo, niveau) VALUES (?,?,?,?,?,?,?,?)");
                        $ins_us_tbl->execute(array($ut_co['id_ut'],$nom_ut,$tel_ut,$genre_ut,$pays_ut,$adr_ut,$photo_ut,$niv_ut));
                        
                        // Partage d'accees 
                        $_SESSION['id_ut']= $ut_co['id_ut'];
                        $_SESSION['email_ut'] = $ut_co['user_ut'];
                        $_SESSION['mdp_ut'] = $ut_co['password_ut'];

                        $sujet = "Bienvenu à New informatique 24";

                        // en-têtes expéditeur
                        $entetes = "From : \"New Informatique 24\"<notification@newinformatique24.com>\n";

                        // en-têtes adresse de retour
                        $entetes .= "Reply-to : henryfiti1@gmail.com\n";

                        // personnes en copie
                        $entetes .= "Cc : henryfiti1@gmail.com\n";
                        $entetes .= "Bcc : henryfiti2@gmail.com\n";

                        // priorité urgente
                        $entetes .= "X-Priority : 1\n";

                        // message
                        $message =
                        "
                            New Informatique 24 Notification en Francais :
                        
                            \r\n \r\n
                            Bienvenu à NEW INFORMATIQUE 24, nous sommes heureux de vous comptez parmis nous et nous esperons developper plus de travail possible avec vous !

                            \r\n \r\n
                            Date d'inscriptio' : " . date('d-m-Y') . " \r\n
                            Site : New Informatique 24 \r\n
                            Adresse : newinformatique24.com \r\n
                        ";
                        
                        mail($email_ut, $sujet, $message, $entetes);
                        
                        header("Location: profil.php?id_utilisateur=" . $_SESSION['id_ut']);

                    }
                    
                } else {
                    $msg = "une erreur est survenu !";
                } 
            
            // Fin verification des 2 mot de passe
            } else {
                $msg = "Vos `mot de passe` ne sont pas verifier !";
            }

        // Fin verification de l'utilisateur sur la table
        } else {
           $msg = "Ce adresse mail est deja utiliser par un utilisateur de new informatique 24, Veullez le changer !";
        }
        
    // Fermeture de la verification de non vide de chaque champs
    } else {
        $msg = "Veuillez remplir les champs completement !";
    }

// Fermeture de la verification d'envoie
}

$og_titre = "New Informatique 24 - Inscription";
$og_desc = "Formulaire d'inscription : veuillez remplir vos informations dans le...";
$og_image = "https://newinformatique24.com/logo.jpg";


?>

<!DOCTYPE html>
<html>
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti, cours, tutoriel">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png">

    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/form.css">

    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body>
    <header>
         <div class="logo">
             <img src="logo.png" alt="logo de New Inforatique 24">
            <h1>New Informatique <span>24</span></h1>
         </div>
     </header>

    <div id="form">
        <form method="post">
            <h3>Formulaire d'inscription</h3>
            <p <?php if(isset($msg)) { ?> style=color:red; <?php } ?> >
                <i><?php if(isset($msg)){ echo $msg; } else { ?>Note : il est obligatoire de tout remplir sur le formulaire ici present ! <?php } ?></i>
            </p>
            <p class="cap">Nom Complet</p>
            <input type="text" name="nom_ut" placeholder="Votre Nom" required>
            <p class="cap">Genre (sexe)</p>
            <select name="genre_ut">
                <option value="homme">Homme</option>
                <option value="femme">Femme</option>
            </select>
            <p class="cap">Pays</p>
            <input type="text" name="pays_ut" placeholder="Votre pays" required>
            <p class="cap">Adresse physique</p>
            <input type="text" name="adr_ut" placeholder="Votre adresse" required>
            <p class="cap">Adresse de messagerie</p>
            <input type="email" name="email_ut" placeholder="Votre email" required>
            <p class="cap">Telephone</p>
            <input type="text" name="tel_ut" placeholder="Votre telephone" required>
            <p class="cap">Creer un Mot de passe</p>
            <input type="password" name="mdp_ut" placeholder="Votre mot de passe" required>
            <p class="cap">Confirmer le mot de passe</p>
            <input type="text" name="mdp2_ut" placeholder="Confirmer mot de passe" required>
            <div class="btn">
                <a href="connexion.php">J'ai dejà un compte ici</a>
                <input type="submit" value="s'inscrire" name="inscrit">   
            </div>      
        </form>
    </div>

    <?php include "inc/footer.php" ?>
</body>
</html>