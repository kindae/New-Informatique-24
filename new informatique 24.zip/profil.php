<?php
require_once "php/config.php";
require_once "php/connexion.php";

$og_titre = "Profil";
$og_desc = "Apprendre l'informatique en quelque jours avec New Informatique. Nous avons des tutoriels et des cours, les cours sont donnés en ligne et sureveiller à 100%...";
$og_image = "https://newinformatique24.com/logo.jpg";


?>

<!DOCTYPE html>
<html>
<head>
    <!-- meta commun -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Informatique, New informatique 24, fmh studio, congo, republique democratique du congo, rdc, kinshasa, henry fiti, cours, tutoriel">
    <meta name="author" content="Henry fiti mbenza">
    <meta property="og:type" content="website" />
    <meta property="fb:app_id" content="765951377439435" />

    <!-- Titre -->
    <title><?= $og_titre ?></title>
    <meta property="og:title" content="<?= $og_titre ?>" />

    <!-- meta details -->
    <meta name="description" content="<?= $og_desc ?>">
    <meta property="og:description" content="<?= $og_desc ?>" />

    <!-- Image -->
    <meta property="og:image" content="<?= $og_image ?>" />
    

    <!-- links -->
    <link rel="alternate" href="rss.php" type="application/rss+xml" title="tutoriels"> 
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="mask-icon" href="logo.png">


    <!-- CSS Styles -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    
    <!-- HEAD code -->
    <?php require "inc/head.php" ?>
</head>
<body>
     
    <?php include "inc/header.php" ?>
     
    <div id="c">

        <?php include "inc/menu.php" ?>

        <div id="pr">
            <div class="profil">
                <div class="ap">
                    <div class="img">
                        <img src="images/profil/<?= $photo_ut ?>" alt="<?= $photo_ut ?>">
                        <div class="btn">
                            <a href="edit_avatar.php">Avatar</a>
                            <a href="profil_edit.php">Profil</a>
                        </div> 
                    </div>
                    <div class="nom">
                        <span><?= $nom_ut ?></span>
                        <span><?= $email_ut ?></span>
                        <a href="edit_password.php">Modifier mot de passe</a>
                        <a href="deconnexion.php">Deconnexion</a>
                    </div> 
                </div>
                <div class="desc">
                    <span class="bleu">Niveau : <?php if($niveau_ut == 0){ echo "Simple";} else { echo $niveau_ut; } ?></span>
                    <span>Pays: <?= $pays_ut ?></span>
                    <span>Adresse: <?= $adresse_ut ?></span>
                    <span>Sexe: <?= $sexe_ut ?></span>
                    <span>Tel: <?= $tel_ut ?></span>
                </div>
                <div class="cours">
                    <h2>Examens resultat</h2>
                    <a>Auncun pour l'instant</a>
                </div> 
                <div class="cours">
                    <h2>Cours en progression</h2>
                    <span>Auncun pour l'instant</span>
                </div>
            </div>
        </div>
    </div>

    <?php include "inc/secondaire.php" ?>

    <?php include "inc/footer.php" ?>

</body>
</html>